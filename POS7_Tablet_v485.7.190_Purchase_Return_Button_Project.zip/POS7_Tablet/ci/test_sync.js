const fs=require('fs'),vm=require('vm'),assert=require('assert');
const text=fs.readFileSync(require('path').resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
const applyText=text.slice(text.indexOf('function apply(row){'),text.indexOf('function syncComparable(',text.indexOf('function apply(row){')));
const chunkText=text.slice(text.indexOf('function patchSize('),text.indexOf('async function refreshCloud(',text.indexOf('function patchSize(')));
function testReceipt(existsInNamedParties){
 const saves=[];
 const state={customers:existsInNamedParties?{'عميل أ':0}:{},suppliers:{},customerPayments:[],supplierPayments:[],sales:[{customer:'عميل أ',debtUSD:60}],expenses:[],mcLedger:[],pos7OwnerApplied:{},fxRate:90000};
 const win={pos265CustomerBalanceUSD:()=>60,mcBalance:()=>300,mcPost:(parts,direction,ref)=>{state.mcLedger.push({parts,direction,ref})},pos7PostJournalEntry:()=>{}};
 const ctx={state,window:win,localStorage:{setItem:(...args)=>saves.push(args)},KEY:'POS7_TRIAL188_CLEAN',journal:()=>{},restore:(dest,old)=>{Object.keys(dest).forEach(k=>delete dest[k]);Object.assign(dest,old)}};
 vm.createContext(ctx);vm.runInContext(applyText,ctx);
 const row={event_id:'same-id',event_type:'customer_payment',payload:{customer:'عميل أ',amount:40,currency:'USD',account:'cashier_usd',fxRate:90000}};
 const first=ctx.apply(row),second=ctx.apply(row);
 assert.equal(first.reference,'OP-same-id');assert.equal(second.reference,first.reference);
 assert.equal(state.customerPayments.length,1);assert.equal(state.mcLedger.length,1);assert.equal(saves.length,1);
 assert.equal(state.customerPayments[0].cloudEventId,'same-id');
 assert.equal(JSON.parse(saves[0][1]).pos7OwnerApplied['same-id'].reference,'OP-same-id');
 return {existsInNamedParties,receipts:state.customerPayments.length,durableWrites:saves.length};
}
console.log('DURABLE CUSTOMER RECEIPT',testReceipt(false),testReceipt(true));
{
 const state={customers:{'عميل أ':100},suppliers:{},customerPayments:[{cloudEventId:'old-id',ref:'OP-old-id'}],supplierPayments:[],expenses:[],pos7OwnerApplied:{},fxRate:90000};
 const ctx={state,window:{},localStorage:{setItem:()=>{}},restore:()=>{}};vm.createContext(ctx);vm.runInContext(applyText,ctx);
 assert.throws(()=>ctx.apply({event_id:'old-id',event_type:'customer_payment',payload:{customer:'عميل أ',amount:40,currency:'USD',account:'cashier_usd'}}),/الحركة موجودة محليًا/);
 console.log('OLD LEGACY EVENT cannot duplicate or auto-reject');
}
const ctx2={baseline:{},syncComparable:(t,v)=>v};vm.createContext(ctx2);vm.runInContext(chunkText,ctx2);
const large={receipts:{upsert:{},remove:[]}};
for(let i=0;i<5801;i++)large.receipts.upsert['rec-'+i]={id:i,ref:'REF-'+i,amount:i};
const chunks=ctx2.patchChunks(large);
assert.equal(chunks.reduce((n,c)=>n+ctx2.patchSize(c),0),5801);
assert.ok(chunks.every(c=>ctx2.patchSize(c)<=40));
const patch0=chunks[0];ctx2.updateBaseline(patch0);
assert.equal(Object.keys(ctx2.baseline.receipts).length,40);
console.log('CHUNKING 5801 rows',chunks.length,'chunks, max',Math.max(...chunks.map(x=>ctx2.patchSize(x))),'entries');
const criticalText=text.slice(text.indexOf('function criticalPatch('),text.indexOf('async function refreshCloud(',text.indexOf('function criticalPatch(')));
{
 const ctx={baseline:{receipts:{},customers:{},cash:{}},syncComparable:(t,v)=>v};vm.createContext(ctx);vm.runInContext(text.slice(text.indexOf('function syncComparable('),text.indexOf('async function delta(',text.indexOf('function syncComparable(')))+criticalText,ctx);
 const receiptId='OP-evt-1';const snap={sections:{receipts:{[receiptId]:{id:receiptId,ref:receiptId,amountUSD:40}},customers:{'عميل أ':{id:'عميل أ',balance:60}},cash:{cashier_usd:{balance:140}},cashLedger:{'row-1':{ref:receiptId,amount:40}}}};
 const p=ctx.criticalPatch(snap,{event_id:'evt-1',event_type:'customer_payment',payload:{customer:'عميل أ',account:'cashier_usd'}});
 assert.deepEqual(Object.keys(p).sort(),['cash','cashLedger','customers','receipts'].sort());
 assert.equal(p.receipts.upsert[receiptId].amountUSD,40);
 console.log('CRITICAL PATCH carries receipt + balance + cash + cash ledger');
}
assert(/diag\.pending===0/.test(text),'Pending must only clear when sync says all changes are uploaded');
assert(!text.includes('POS7_HTML_READONLY_PREVIEW'));
console.log('AUTOMATIC RETRY remains pending until backlog drains');
