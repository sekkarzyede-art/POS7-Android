# POS7 Tablet v485.7.187 — trial / source-verified

- Navigation warning on unsaved sale or purchase invoices with Stay/Discard choices.
- Sales: clear only the selected one of three drafts; do not modify posted invoices.
- Purchases: use the existing purchase draft clear operation.
- Background activity no longer cancels a committed post-save cloud sync via generation count alone. An active unfinished invoice still pauses sync.
- Maintains the original application ID, original certificate enforcement, GitHub secret names and existing data keys.
- Includes an updated v187 GitHub Actions main.yml. Uses a strictly greater versionCode when the installed value is provided.

**Tests on-device and live Supabase/Android notifications are still required.** Do not use the previous v187 ZIP, which had an invalid HTML insertion and stale build workflow.
