# POS7 Tablet 485.7.190 — Purchase Return Button

Based on v485.7.189 supplier-specific quick item list, itself based on v485.7.188 midnight-date fix.

- Adds an adjacent **عودة إلى الأصناف** next to **حفظ فاتورة الشراء** in the purchase calculator.
- Return closes only the calculator view and brings the purchase cart into view; does NOT save, discard, clear or change the purchase draft.
- Keeps the calculator's existing layout unchanged, per user correction that no content was missing.
- Hides duplicate legacy return button near calculator heading.
- Preserves native Java, Supabase sync, ledgers, invoice date guards, product selector, backup flows and original signing settings.
- Application id stays com.sokkarzeyedeh.pos7; original signing SHA256 required.
- To update APK v485.7.188 with versionCode 48508229, build signed release with versionCode >=48508230.

Validation: node syntax and CI checks; Android signed release and actual live device behavior require GitHub Actions and physical installation.
