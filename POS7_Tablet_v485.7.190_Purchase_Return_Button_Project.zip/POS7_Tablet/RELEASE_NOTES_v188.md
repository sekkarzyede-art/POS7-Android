# POS7 Tablet v485.7.188 — midnight basket date fix

Private store baseline: v485.7.187; package `com.sokkarzeyedeh.pos7` unchanged.

## Scope
- Three sale baskets store an additional `manualDate` flag when the user explicitly changes the date input.
- Automatic draft dates refresh to the **device-local day** on restoring, re-opening, returning to foreground, and at save time; while visible also checked every 15 seconds.
- An explicitly selected date different from today is preserved and confirmed before saving. Declining confirmation leaves the invoice unsaved.
- Editing a pre-existing sale is exempt from date refresh; its original accounting date and invoice number remain unchanged.
- No existing invoice is rewritten or renumbered. Purchases, cash ledger, cloud-sync implementation and credentials are untouched.
- Before installing, back up live store data and confirm update signing/versionCode.

## Verified locally
- JavaScript syntax checks for all inline scripts.
- Node CI tests including date guard logic and prior sync/accounting regression tests.
- Headless Chromium simulated 04 Nov -> 05 Nov midnight: automatic draft advanced, manual backdate confirmed, existing edit unchanged, and three independent baskets refreshed as expected.
- Actual signed APK must be built using your existing GitHub Secrets and tested as an in-place upgrade.

## Historical data
Invoices such as SAL-000560 and test invoices 604–606 are NOT modified by this code. Review and correct their accounting dates and linked transactions separately, using a verified backup and audit trail.
