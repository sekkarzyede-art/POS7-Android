# POS7 Tablet v485.7.186 — Auto Sync and Save Probe Fold

Starting point: production v485.7.185 BuildFix1.

Changes: (1) diagnostic save-speed button shows for two seconds then collapses to a 42px clock icon; remains tappable for manual report reopening. (2) automatic sync no longer treats the mere sales/purchase page being active as a busy invoice; it defers for unsaved carts, edit state and visible calculators. (3) after-save retry completion observes `pos177SyncDiagnostics.get().lastSuccess` rather than an unwritten variable. (4) safe idle catch-up on startup/foreground without visiting sync page.

Unchanged: `pos181Fingerprint` deterministic JSONB comparison; Supabase RPCs; financial command acknowledgements and idempotency; signing identity; package; local storage key; external backup manager and BuildFix1 Java exception handling.

Limitations: JavaScript WebView syncing needs the tablet app foreground and internet. Android OS can suspend timers when the app is backgrounded/screen locked; no 24/7 background guarantee. Owner-phone FCM notification display must be diagnosed/fixed in the separate owner phone APK, not this tablet update.

Upgrade safely: external backup first; never uninstall old app or clear app data; existing installed versionCode should be entered in manual GitHub Actions run if higher than 48507930. Keep all four original signing secrets and cert check.
