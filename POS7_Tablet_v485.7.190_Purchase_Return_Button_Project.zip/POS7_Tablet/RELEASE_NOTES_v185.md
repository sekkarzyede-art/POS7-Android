# POS7 tablet v485.7.185 — Diagnostic release

Based on production v485.7.183. Includes product save/back layout, external backup folder bridge, and non-mutating save latency diagnostics ported from v485.7.184 browser test.

No accounting, cloud sync comparison, or receipt rules changed in this release.

This release measures save time; it does NOT yet fix latency. The profiling dashboard and a copied report do not certify durability.

The archive must be built in GitHub Actions with the original four secrets and the original certificate. Do not uninstall POS7 or install an unsigned/debug-key APK; take independent backup before install. Supply actual installed versionCode via workflow dispatch if the previous build may have a higher code than the CI default.

Release testing: JavaScript syntax, stable JSONB sync, idempotent receipt handling, backups, static profile wiring. Real-device Android build/install, signing, save performance, and FCM remain to be verified on GitHub/target tablet.


### BuildFix1 — Java checked exception
- Wrap `DriveBackupManager.validate(saved)` in `writeBackupToTree()` with a checked-exception handler that propagates `IOException`.
- No changes to financial logic, Firebase/Supabase synchronization, package ID, version name, or signing policy.
- A failed backup validation prevents pruning previously saved backups.
