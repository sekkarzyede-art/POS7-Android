# POS7 — بناء APK التاب والهاتف

تحتوي الحزمة على مشروعين مستقلين: واجهة التاب v485.7.65 وواجهة الهاتف v485.7.66. يحتفظ المشروعان بمعرّف Android `com.sokkarzeyedeh.pos7` ومفتاح التوقيع نفسه، ويستخدمان `versionCode` 487 لتثبيت البناء كتحديث على النسخة السابقة.

ارفع ملف ZIP إلى المستودع، وانسخ `main.yml` المرفق إلى `.github/workflows/main.yml`. شغّل GitHub Actions، ثم نزّل artifact التاب والهاتف كلٌّ على حدة. يحتاج المستودع أسرار التوقيع الأربعة المعتادة: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`.
