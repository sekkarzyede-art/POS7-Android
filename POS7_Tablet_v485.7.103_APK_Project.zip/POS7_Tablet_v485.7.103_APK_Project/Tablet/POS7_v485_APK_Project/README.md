# POS7 Tablet APK Project v485.7.103

- Application ID: `com.sokkarzeyedeh.pos7` (unchanged, for in-place updates).
- Version code: `48507103`; version name: `485.7.103`.
- Includes the latest POS7 HTML build with the voucher remaining balance shown for customer receipts and supplier payments.
- Preserves the POS7 tablet release signing certificate check. Owner phone app and its data are not changed.

Build through the included GitHub Actions workflow using the same POS7 tablet release keystore used for the installed tablet APK. Configure repository secrets `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The workflow checks certificate SHA-256 `843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495` before and after build; mismatch stops the build to prevent an incompatible update.
