# POS7 APK Project — v485.7.55 Cloud Sync

This build keeps POS7's existing local database and adds an owner-controlled first upload plus cloud event intake for phone expenses and customer receipts.

## Before using sync

1. Keep the current tablet data and make a backup from POS7.
2. In Supabase SQL Editor, run `POS7_Supabase_Sync_Migration.sql` once. The base schema has already been installed.
3. Create a separate phone login under Authentication → Users → Add user. Use the account email for the SQL membership command below. Do not use the database password or a service-role key in the app.
4. Grant the phone role by running in SQL Editor (replace the email):

```sql
insert into public.pos7_members (user_id, store_id, role)
select id, 'pos7', 'phone_entry'
from auth.users
where lower(email) = lower('phone@example.com')
on conflict (user_id, store_id) do update set role = excluded.role;
```

5. Install this update on the company tablet, sign in to **☁ مزامنة POS7** with the existing owner account, then press **رفع بيانات التاب الأولية مرة واحدة**. It refuses to overwrite an existing cloud snapshot.
6. Install the companion phone APK and sign in with the separate phone account.

The tablet remains locally usable offline. Phone actions are queued if the phone is offline. When the tablet reconnects, it checks the current customer and cashbox balance before applying each event; duplicate event IDs are ignored. If the tablet is closed/offline, phone actions remain pending until it reconnects.

The phone APK source is in `POS7_Phone_Entry_APK_Project/`; the standalone page is also provided as `POS7_Phone_Entry.html`.

## GitHub Actions signing

The company APK update must use the same keystore/alias as the installed POS7 APK. Add these repository secrets: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The phone app has a different application ID and can use the same signing key.
