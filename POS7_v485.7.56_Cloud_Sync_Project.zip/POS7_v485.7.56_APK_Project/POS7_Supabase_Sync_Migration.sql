-- POS7 sync v2: additive upgrade only; leaves POS7 local data untouched.
-- Run after POS7_Supabase_Setup.sql.

alter table public.pos7_mobile_events
  add column if not exists status text not null default 'pending',
  add column if not exists processed_at timestamptz,
  add column if not exists processed_by uuid references auth.users(id),
  add column if not exists result jsonb not null default '{}'::jsonb;

do $$ begin
  if not exists (
    select 1 from pg_constraint
    where conrelid = 'public.pos7_mobile_events'::regclass
      and conname = 'pos7_mobile_events_status_check'
  ) then
    alter table public.pos7_mobile_events
      add constraint pos7_mobile_events_status_check
      check (status in ('pending','processed','rejected'));
  end if;
end $$;

create index if not exists pos7_mobile_events_pending_idx
  on public.pos7_mobile_events (store_id, status, created_at);

drop policy if exists pos7_events_update_manager on public.pos7_mobile_events;
create policy pos7_events_update_manager on public.pos7_mobile_events
  for update to authenticated
  using (public.pos7_is_member(store_id, array['owner','manager']))
  with check (public.pos7_is_member(store_id, array['owner','manager']));

grant update on public.pos7_mobile_events to authenticated;

-- Mobile users can check only their own submissions; managers can see the queue.
drop policy if exists pos7_events_read_member on public.pos7_mobile_events;
create policy pos7_events_read_member on public.pos7_mobile_events
  for select to authenticated
  using (
    created_by = auth.uid()
    or public.pos7_is_member(store_id, array['owner','manager'])
  );

-- The phone must not be able to read the full POS snapshot (which may contain
-- invoices, supplier details, staff data, and audit records). It receives a
-- deliberately reduced snapshot with customer names/debts and cash balances.
drop policy if exists pos7_state_read_member on public.pos7_store_state;
create policy pos7_state_read_manager on public.pos7_store_state
  for select to authenticated using (public.pos7_is_member(store_id, array['owner','manager']));

create table if not exists public.pos7_phone_snapshot (
  store_id text primary key default 'pos7' check (store_id = 'pos7'),
  snapshot jsonb not null default '{}'::jsonb,
  revision bigint not null default 0 check (revision >= 0),
  updated_at timestamptz not null default now(),
  updated_by uuid references auth.users(id)
);
alter table public.pos7_phone_snapshot enable row level security;
drop policy if exists pos7_phone_snapshot_read_member on public.pos7_phone_snapshot;
create policy pos7_phone_snapshot_read_member on public.pos7_phone_snapshot
  for select to authenticated using (public.pos7_is_member(store_id));
drop policy if exists pos7_phone_snapshot_insert_manager on public.pos7_phone_snapshot;
create policy pos7_phone_snapshot_insert_manager on public.pos7_phone_snapshot
  for insert to authenticated
  with check (public.pos7_is_member(store_id, array['owner','manager']));
drop policy if exists pos7_phone_snapshot_update_manager on public.pos7_phone_snapshot;
create policy pos7_phone_snapshot_update_manager on public.pos7_phone_snapshot
  for update to authenticated
  using (public.pos7_is_member(store_id, array['owner','manager']))
  with check (public.pos7_is_member(store_id, array['owner','manager']));
grant select, insert, update on public.pos7_phone_snapshot to authenticated;

do $$ begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'pos7_mobile_events'
  ) then
    alter publication supabase_realtime add table public.pos7_mobile_events;
  end if;
end $$;
