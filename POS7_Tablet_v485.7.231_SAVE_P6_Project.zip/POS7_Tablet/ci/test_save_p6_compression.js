'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const pakoSource=html.match(/<script id="pos7-pako-1\.0\.11">([\s\S]*?)<\/script>/)[1];
const adapter=html.match(/<script id="pos7-localstorage-compression-v1">([\s\S]*?)<\/script>/)[1];
class Storage {
 constructor(limit=Infinity){this.data=new Map();this.limit=limit;}
 get length(){return this.data.size}
 key(i){return [...this.data.keys()][i]??null}
 getItem(key){return this.data.get(String(key))??null}
 setItem(key,value){const copy=new Map(this.data);copy.set(String(key),String(value));const size=[...copy.values()].reduce((n,s)=>n+s.length,0);if(size>this.limit){const e=Error('quota');e.name='QuotaExceededError';throw e;}this.data=copy}
 removeItem(key){this.data.delete(String(key))}
}
const storage=new Storage();
const ctx={Storage,window:{localStorage:storage},console,Uint8Array,ArrayBuffer,TextEncoder,TextDecoder,btoa:s=>Buffer.from(s,'binary').toString('base64'),atob:s=>Buffer.from(s,'base64').toString('binary')};
vm.createContext(ctx);vm.runInContext(pakoSource,ctx);vm.runInContext(adapter,ctx);
const products=Array.from({length:2200},(_,i)=>({id:100000+i,name:'منتج اختبار '+i,barcode:String(520000000000+i),stock:i%30,price:13.15,cost:10.12,notes:'Sample text for compression '+i}));
const raw=JSON.stringify({products,sales:products.slice(0,100),meta:{revision:33}});
const t0=performance.now();storage.setItem('POS7_TRIAL188_CLEAN',raw);const fast=performance.now()-t0;
assert.equal(storage.getItem('POS7_TRIAL188_CLEAN'),raw,'roundtrip must restore identical JSON');
assert(storage.data.get('POS7_TRIAL188_CLEAN').startsWith('__POS7_LOCAL_JSON_DEFLATE_V1__'));
const def6=ctx.window.pako.deflate(raw,{level:6});const def1=ctx.window.pako.deflate(raw,{level:1});
assert(def1.length<raw.length,'level 1 should still compress sample');
const denseSize= '__POS7_LOCAL_JSON_DEFLATE_V1__'.length + Buffer.from(def6).toString('base64').length;
const fastSize=storage.data.get('POS7_TRIAL188_CLEAN').length;
if(denseSize<fastSize){
 const limited=new Storage(denseSize+1);
 ctx.window.localStorage=limited;
 limited.setItem('POS7_TRIAL188_CLEAN',raw);
 assert.equal(limited.getItem('POS7_TRIAL188_CLEAN'),raw,'quota fallback must preserve entire JSON');
 assert(limited.data.get('POS7_TRIAL188_CLEAN').length<=denseSize+1,'fallback should retry strong compression');
}
console.log('PASS SAVE-P6 compression: lossless roundtrip, level1 compressed, strong fallback verified');
console.log(JSON.stringify({raw_chars:raw.length,fast_chars:fastSize,strong_chars:denseSize,fast_ms:+fast.toFixed(1)}));
