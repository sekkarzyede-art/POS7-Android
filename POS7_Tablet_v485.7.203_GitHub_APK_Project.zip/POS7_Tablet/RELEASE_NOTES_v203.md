# POS7 Tablet v485.7.203 — release source

- Built on the established v485.7.191 tablet Android wrapper and UI-only HTML revisions up to v485.7.203.
- Quick-sale colored groups with current-cart quantities, keyboard folding, one-row sales footer, green Haseb, hiding groups during Haseb.
- Internal POS7_APP_VERSION and displayed version unified to v485.7.203.
- Android applicationId: com.sokkarzeyedeh.pos7.
- Signing is possible ONLY in GitHub Actions with existing original keystore secrets. Build fails on absent or different keys.
- Existing synchronization Java/Kotlin sources and notification bridge unchanged from v485.7.191.
- No user/shop data should be placed in this source ZIP.
- IMPORTANT: Only upload ZIP and workflow to GitHub as instructed. The ZIP is NOT a signed APK.
