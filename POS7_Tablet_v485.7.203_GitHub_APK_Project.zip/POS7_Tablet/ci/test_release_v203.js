const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
assert(html.includes("window.POS7_APP_VERSION='485.7.203'"));
assert(gradle.includes("versionName '485.7.203'"));
for(const marker of ['pos193-quick-script','pos201-single-line-sales-ui','pos203-hide-groups-during-haseb','pos200StickyCalc','pos192Rail'])
  assert(html.includes(marker),'missing '+marker);
assert(gradle.includes("applicationId 'com.sokkarzeyedeh.pos7'"));
console.log('POS7 tablet v203 package and UI checks passed');
