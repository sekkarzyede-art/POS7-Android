package com.sokkarzeyedeh.pos7;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.webkit.WebResourceRequest;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.SharedPreferences;
import android.util.Base64;
import java.io.OutputStream;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.UUID;

public final class MainActivity extends Activity {
    private WebView webView;
    private final ArrayList<WebView> printWebViews = new ArrayList<>();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 4510;
    private static final int BLUETOOTH_PERMISSION_REQUEST = 4711;
    private static final int BLUETOOTH_ENABLE_REQUEST = 4712;
    private static final String PREFS = "pos7_printer";
    private static final String PREF_ADDRESS = "bluetooth_address";
    private static final String PREF_NAME = "bluetooth_name";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private Runnable pendingBluetoothAction;
    private boolean pickAfterBluetoothEnable;
    private volatile boolean bluetoothPrintBusy;
    private final ArrayList<BluetoothDevice> printerChoices = new ArrayList<>();
    private final ArrayList<String> printerChoiceLabels = new ArrayList<>();
    private ArrayAdapter<String> printerChoiceAdapter;
    private AlertDialog printerPickerDialog;
    private TextView printerScanStatus;
    private BroadcastReceiver bluetoothReceiver;
    private boolean bluetoothReceiverRegistered;
    private BluetoothDevice pendingBondDevice;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidPrintBridge(this), "Pos7Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return handleWebNavigation(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return handleWebNavigation(Uri.parse(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                notifyJsPrinterSelected();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean handleWebNavigation(Uri uri) {
        String scheme = uri == null ? null : uri.getScheme();
        if (scheme == null || "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme) ||
                "file".equalsIgnoreCase(scheme) || "content".equalsIgnoreCase(scheme) ||
                "data".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme) ||
                "javascript".equalsIgnoreCase(scheme) || "blob".equalsIgnoreCase(scheme)) return false;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception e) {
            Toast.makeText(this, "لا يوجد تطبيق مثبت لفتح هذا الرابط", Toast.LENGTH_LONG).show();
        }
        return true;
    }

    private final class AndroidPrintBridge {
        private final Context context;
        AndroidPrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printHtml(String html, String jobName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(context, "محتوى الطباعة فارغ", Toast.LENGTH_SHORT).show());
                return;
            }
            runOnUiThread(() -> openSystemPrint(html, jobName));
        }

        @JavascriptInterface public void chooseBluetoothPrinter() {
            runOnUiThread(() -> withBluetoothPermission(() -> showBondedPrinterPicker(false)));
        }

        @JavascriptInterface public String getSelectedBluetoothPrinterName() {
            return getPrinterPrefs().getString(PREF_NAME, "");
        }

        @JavascriptInterface public String getSelectedBluetoothPrinterAddress() {
            return getPrinterPrefs().getString(PREF_ADDRESS, "");
        }

        @JavascriptInterface public void printBluetoothBase64(String encoded, String jobName) {
            if (encoded == null || encoded.isEmpty()) {
                notifyJsPrintResult(false, "بيانات الطباعة فارغة");
                return;
            }
            final byte[] bytes;
            try { bytes = Base64.decode(encoded, Base64.DEFAULT); }
            catch (IllegalArgumentException e) {
                notifyJsPrintResult(false, "تعذر تجهيز بيانات الطباعة");
                return;
            }
            String address = getPrinterPrefs().getString(PREF_ADDRESS, "");
            if (address.isEmpty()) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "اختر أو اقترن بطابعة Bluetooth أولاً", Toast.LENGTH_LONG).show();
                    withBluetoothPermission(() -> showBondedPrinterPicker(false));
                });
                return;
            }
            runOnUiThread(() -> withBluetoothPermission(() -> sendToBluetoothPrinter(address, bytes, jobName)));
        }
    }

    private SharedPreferences getPrinterPrefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void withBluetoothPermission(Runnable action) {
        ArrayList<String> missing = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.BLUETOOTH_CONNECT);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.BLUETOOTH_SCAN);
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
        }
        if (!missing.isEmpty()) {
            pendingBluetoothAction = action;
            requestPermissions(missing.toArray(new String[0]), BLUETOOTH_PERMISSION_REQUEST);
            return;
        }
        action.run();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BLUETOOTH_PERMISSION_REQUEST) {
            Runnable action = pendingBluetoothAction;
            pendingBluetoothAction = null;
            boolean granted = grantResults.length > 0;
            for (int result : grantResults) granted &= result == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                if (action != null) action.run();
            } else {
                Toast.makeText(this, "اسمح للتطبيق بالوصول إلى Bluetooth لاختيار الطابعة", Toast.LENGTH_LONG).show();
                notifyJsPrinterResult("permission", "يلزم السماح بالوصول إلى Bluetooth");
            }
        }
    }

    private void showBondedPrinterPicker(boolean afterEnable) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(this, "هذا الجهاز لا يدعم Bluetooth", Toast.LENGTH_LONG).show();
            notifyJsPrinterResult("unavailable", "الجهاز لا يدعم Bluetooth");
            return;
        }
        if (!adapter.isEnabled()) {
            pickAfterBluetoothEnable = true;
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), BLUETOOTH_ENABLE_REQUEST); }
            catch (Exception e) {
                Toast.makeText(this, "فعّل Bluetooth من إعدادات الهاتف ثم أعد اختيار الطابعة", Toast.LENGTH_LONG).show();
                notifyJsPrinterResult("disabled", "فعّل Bluetooth ثم أعد المحاولة");
            }
            return;
        }
        try {
            printerChoices.clear();
            printerChoiceLabels.clear();
            ArrayList<BluetoothDevice> bonded = new ArrayList<>(adapter.getBondedDevices());
            Collections.sort(bonded, Comparator.comparing((BluetoothDevice d) -> safeDeviceName(d).toLowerCase()));
            for (BluetoothDevice device : bonded) addPrinterChoice(device, "مقترنة");
            ensureBluetoothReceiver();

            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            int pad = dp(12);
            panel.setPadding(pad, pad, pad, 0);
            printerScanStatus = new TextView(this);
            printerScanStatus.setText("اختر طابعة مقترنة، أو اضغط «بحث عن طابعات جديدة» للاقتران من هنا.");
            printerScanStatus.setPadding(0, 0, 0, dp(8));
            panel.addView(printerScanStatus, new LinearLayout.LayoutParams(-1, -2));
            ListView list = new ListView(this);
            printerChoiceAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, printerChoiceLabels);
            list.setAdapter(printerChoiceAdapter);
            panel.addView(list, new LinearLayout.LayoutParams(-1, dp(300)));
            list.setOnItemClickListener((parent, view, position, id) -> {
                if (position >= 0 && position < printerChoices.size()) {
                    BluetoothDevice chosen = printerChoices.get(position);
                    if (printerPickerDialog != null) printerPickerDialog.dismiss();
                    selectOrPairPrinter(chosen);
                }
            });
            printerPickerDialog = new AlertDialog.Builder(this)
                .setTitle("اختيار أو اقتران طابعة Bluetooth")
                .setView(panel)
                .setPositiveButton("بحث عن طابعات جديدة", null)
                .setNegativeButton("إغلاق", (dialog, which) -> stopPrinterDiscovery())
                .create();
            printerPickerDialog.setOnDismissListener(dialog -> {
                if (pendingBondDevice == null) stopPrinterDiscovery();
            });
            printerPickerDialog.show();
            printerPickerDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(view -> {
                if (BluetoothAdapter.getDefaultAdapter().isDiscovering()) {
                    stopPrinterDiscovery();
                    updatePrinterScanStatus("توقف البحث. اختر جهازًا من القائمة أو ابدأ البحث مجددًا.");
                    printerPickerDialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("بحث عن طابعات جديدة");
                } else {
                    startPrinterDiscovery(adapter);
                    printerPickerDialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("إيقاف البحث");
                }
            });
        } catch (SecurityException e) {
            Toast.makeText(this, "لم يسمح Android بالوصول إلى أجهزة Bluetooth؛ اسمح بإذن الأجهزة القريبة.", Toast.LENGTH_LONG).show();
            notifyJsPrinterResult("permission", "اسمح بإذني الأجهزة القريبة وBluetooth ثم أعد المحاولة");
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void ensureBluetoothReceiver() {
        if (bluetoothReceiverRegistered) return;
        bluetoothReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                    BluetoothDevice device = getBluetoothDevice(intent);
                    if (device != null) addPrinterChoice(device, "قريبة");
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED.equals(action)) {
                    updatePrinterScanStatus("انتهى البحث. اختر الطابعة من القائمة أو أعد البحث.");
                    if (printerPickerDialog != null && printerPickerDialog.isShowing())
                        printerPickerDialog.getButton(AlertDialog.BUTTON_POSITIVE).setText("بحث عن طابعات جديدة");
                } else if (BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action)) {
                    BluetoothDevice device = getBluetoothDevice(intent);
                    if (device == null || pendingBondDevice == null ||
                            !pendingBondDevice.getAddress().equals(device.getAddress())) return;
                    int state = intent.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR);
                    if (state == BluetoothDevice.BOND_BONDED) {
                        pendingBondDevice = null;
                        saveSelectedPrinter(device);
                        notifyJsPrinterResult("paired", "تم الاقتران واختيار الطابعة؛ يمكنك الآن إجراء اختبار الطباعة");
                    } else if (state == BluetoothDevice.BOND_NONE) {
                        pendingBondDevice = null;
                        notifyJsPrinterResult("pair_failed", "لم يكتمل الاقتران. تحقق من رمز الطابعة وأعد المحاولة");
                    } else if (state == BluetoothDevice.BOND_BONDING) {
                        notifyJsPrinterResult("pairing", "أكّد طلب الاقتران في نافذة Android إذا ظهرت");
                    }
                }
            }
        };
        IntentFilter filter = new IntentFilter();
        filter.addAction(BluetoothDevice.ACTION_FOUND);
        filter.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        if (Build.VERSION.SDK_INT >= 33)
            registerReceiver(bluetoothReceiver, filter, Context.RECEIVER_EXPORTED);
        else registerReceiver(bluetoothReceiver, filter);
        bluetoothReceiverRegistered = true;
    }

    private BluetoothDevice getBluetoothDevice(Intent intent) {
        if (Build.VERSION.SDK_INT >= 33)
            return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
        //noinspection deprecation
        return intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
    }

    private void addPrinterChoice(BluetoothDevice device, String source) {
        if (device == null) return;
        String address;
        try { address = device.getAddress(); } catch (SecurityException e) { return; }
        for (int i = 0; i < printerChoices.size(); i++) {
            if (address.equals(printerChoices.get(i).getAddress())) {
                if ("مقترنة".equals(source) && !printerChoiceLabels.get(i).contains("مقترنة"))
                    printerChoiceLabels.set(i, safeDeviceName(device) + "  •  " + address + "  (مقترنة)");
                if (printerChoiceAdapter != null) printerChoiceAdapter.notifyDataSetChanged();
                return;
            }
        }
        printerChoices.add(device);
        printerChoiceLabels.add(safeDeviceName(device) + "  •  " + address + "  (" + source + ")");
        if (printerChoiceAdapter != null) printerChoiceAdapter.notifyDataSetChanged();
    }

    private void startPrinterDiscovery(BluetoothAdapter adapter) {
        ensureBluetoothReceiver();
        try {
            printerChoices.clear();
            printerChoiceLabels.clear();
            for (BluetoothDevice device : adapter.getBondedDevices()) addPrinterChoice(device, "مقترنة");
            printerChoiceAdapter.notifyDataSetChanged();
            updatePrinterScanStatus("جارٍ البحث عن الطابعات القريبة… اجعل الطابعة في وضع الاقتران.");
            boolean started = adapter.startDiscovery();
            if (!started) updatePrinterScanStatus("تعذر بدء البحث. تأكد من تشغيل Bluetooth ثم أعد المحاولة.");
        } catch (SecurityException e) {
            updatePrinterScanStatus("إذن البحث عن أجهزة Bluetooth غير ممنوح؛ فعّل إذن الأجهزة القريبة للتطبيق.");
        }
    }

    private void stopPrinterDiscovery() {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && adapter.isDiscovering()) adapter.cancelDiscovery();
        } catch (SecurityException ignored) { }
    }

    private void updatePrinterScanStatus(String message) {
        if (printerScanStatus != null) printerScanStatus.setText(message);
    }

    private void selectOrPairPrinter(BluetoothDevice device) {
        try {
            if (device.getBondState() == BluetoothDevice.BOND_BONDED) {
                saveSelectedPrinter(device);
                return;
            }
            pendingBondDevice = device;
            notifyJsPrinterResult("pairing", "جارٍ اقتران " + safeDeviceName(device) + "؛ أكّد الطلب على Android إذا ظهر");
            if (!device.createBond()) {
                pendingBondDevice = null;
                notifyJsPrinterResult("pair_failed", "تعذر بدء الاقتران. أعد وضع الطابعة في وضع الاقتران وحاول مجددًا");
            }
        } catch (SecurityException e) {
            pendingBondDevice = null;
            notifyJsPrinterResult("permission", "اسمح بإذن الأجهزة القريبة ثم أعد الاقتران");
        }
    }

    private String safeDeviceName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return (name == null || name.trim().isEmpty()) ? "طابعة Bluetooth" : name.trim();
        } catch (SecurityException e) { return "طابعة Bluetooth"; }
    }

    private void saveSelectedPrinter(BluetoothDevice device) {
        String name = safeDeviceName(device), address = device.getAddress();
        getPrinterPrefs().edit().putString(PREF_NAME, name).putString(PREF_ADDRESS, address).apply();
        Toast.makeText(this, "تم اختيار " + name, Toast.LENGTH_SHORT).show();
        notifyJsPrinterSelected();
    }

    private void sendToBluetoothPrinter(String address, byte[] bytes, String jobName) {
        if (bluetoothPrintBusy) {
            notifyJsPrintResult(false, "الطابعة مشغولة بطباعة سابقة؛ انتظر اكتمالها ثم أعد المحاولة");
            return;
        }
        bluetoothPrintBusy = true;
        new Thread(() -> {
            BluetoothSocket socket = null;
            boolean success = false;
            String resultMessage;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new IOException("Bluetooth غير متاح");
                BluetoothDevice device = adapter.getRemoteDevice(address);
                socket = connectPrinterSocket(device);
                // امنح اتصال SPP وقتًا قصيرًا للاستقرار قبل إرسال أمر التهيئة المضمن مرة واحدة في الحمولة.
                Thread.sleep(200);
                OutputStream output = socket.getOutputStream();
                // الحمولة تبدأ بـ ESC @ ثم بيانات الصورة. لا نكرر التهيئة هنا كي لا تقطع أمر الرسم.
                int offset = 0;
                while (offset < bytes.length) {
                    // دُفعات متصلة أكبر تقلل التأخير، مع إبقاء الكتابة متوافقة مع مخازن SPP المحدودة.
                    int count = Math.min(4096, bytes.length - offset);
                    output.write(bytes, offset, count);
                    offset += count;
                }
                output.flush();
                // لا توجد إشارة اكتمال ورقي معيارية في SPP؛ ننتظر قليلًا لتفريغ المخزن قبل إغلاق الاتصال.
                long drainWaitMs = Math.max(1500L, Math.min(8000L, 1000L + (bytes.length / 20000L) * 1000L));
                Thread.sleep(drainWaitMs);
                success = true;
                resultMessage = "أُرسلت بيانات الإيصال إلى " + getPrinterPrefs().getString(PREF_NAME, "الطابعة") + ". تحقق من خروج الورقة.";
            } catch (Exception e) {
                String message = e.getMessage() == null ? "تعذر الاتصال بالطابعة" : e.getMessage();
                resultMessage = "فشل الاتصال بالطابعة: " + message;
            } finally {
                if (socket != null) try { socket.close(); } catch (IOException ignored) { }
                bluetoothPrintBusy = false;
            }
            notifyJsPrintResult(success, resultMessage);
        }, "POS7-Bluetooth-Printer").start();
    }

    private BluetoothSocket connectPrinterSocket(BluetoothDevice device) throws IOException {
        IOException secureFailure;
        BluetoothSocket secureSocket = null;
        try {
            secureSocket = device.createRfcommSocketToServiceRecord(SPP_UUID);
            cancelBluetoothDiscoveryBeforeConnect();
            secureSocket.connect();
            return secureSocket;
        } catch (IOException e) {
            secureFailure = e;
            if (secureSocket != null) try { secureSocket.close(); } catch (IOException ignored) { }
        }

        BluetoothSocket fallbackSocket = null;
        try {
            // كثير من طابعات ESC/POS الحرارية تقبل SPP غير الآمن فقط بعد الاقتران.
            fallbackSocket = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID);
            cancelBluetoothDiscoveryBeforeConnect();
            fallbackSocket.connect();
            return fallbackSocket;
        } catch (IOException e) {
            if (fallbackSocket != null) try { fallbackSocket.close(); } catch (IOException ignored) { }
            Exception secureChannelFailure;
            try {
                // بعض الطابعات القديمة لا تعلن سجل SPP عبر SDP؛ جرّب قناة RFCOMM الشائعة مباشرة.
                return connectReflectedPrinterChannel(device, "createRfcommSocket");
            } catch (Exception secureReflectionException) {
                secureChannelFailure = secureReflectionException;
            }
            try {
                return connectReflectedPrinterChannel(device, "createInsecureRfcommSocket");
            } catch (Exception insecureChannelFailure) {
                String first = secureFailure.getMessage() == null ? "رفض الاتصال الآمن" : secureFailure.getMessage();
                String second = e.getMessage() == null ? "رفض اتصال SPP البديل" : e.getMessage();
                String third = secureChannelFailure.getMessage() == null ? "رفض قناة RFCOMM الآمنة" : secureChannelFailure.getMessage();
                String fourth = insecureChannelFailure.getMessage() == null ? "رفض قناة RFCOMM البديلة" : insecureChannelFailure.getMessage();
                insecureChannelFailure.addSuppressed(secureChannelFailure);
                throw new IOException("تعذر فتح اتصال الطابعة عبر SPP. تحقق من تشغيلها واقترانها وقربها من الجهاز. (" + first + " / " + second + " / قناة 1 آمنة: " + third + " / قناة 1 بديلة: " + fourth + ")", insecureChannelFailure);
            }
        }
    }

    private void cancelBluetoothDiscoveryBeforeConnect() throws IOException {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) throw new IOException("Bluetooth غير متاح");
        try {
            // يوصي Android بإيقاف أي بحث جارٍ قبل connect() حتى لو لم يبدأه التطبيق.
            adapter.cancelDiscovery();
        } catch (SecurityException permissionError) {
            throw new IOException("يلزم إذن الأجهزة القريبة لإيقاف بحث Bluetooth قبل الاتصال", permissionError);
        }
    }

    private BluetoothSocket connectReflectedPrinterChannel(BluetoothDevice device, String methodName) throws Exception {
        Method method = device.getClass().getMethod(methodName, int.class);
        BluetoothSocket channelSocket = (BluetoothSocket) method.invoke(device, 1);
        try {
            cancelBluetoothDiscoveryBeforeConnect();
            channelSocket.connect();
            return channelSocket;
        } catch (Exception e) {
            try { channelSocket.close(); } catch (IOException ignored) { }
            throw e;
        }
    }

    private void notifyJsPrinterSelected() {
        if (webView == null) return;
        String name = getPrinterPrefs().getString(PREF_NAME, "");
        String address = getPrinterPrefs().getString(PREF_ADDRESS, "");
        String js = "if(window.pos7OnBluetoothPrinterSelected)window.pos7OnBluetoothPrinterSelected(" +
                org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(address) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyJsPrinterResult(String code, String message) {
        if (webView == null) return;
        String js = "if(window.pos7OnBluetoothPrinterResult)window.pos7OnBluetoothPrinterResult(" +
                org.json.JSONObject.quote(code) + "," + org.json.JSONObject.quote(message) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyJsPrintResult(boolean success, String message) {
        runOnUiThread(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            if (webView != null) {
                String js = "if(window.pos7BluetoothPrintResult)window.pos7BluetoothPrintResult(" + success + "," +
                        org.json.JSONObject.quote(message) + ");";
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private void openSystemPrint(String html, String jobName) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
        WebView printView = new WebView(this);
        printWebViews.add(printView);
        printView.getSettings().setJavaScriptEnabled(true);
        printView.setWebViewClient(new WebViewClient() {
            private boolean started;
            @Override public void onPageFinished(WebView view, String url) {
                if (started) return;
                started = true;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager == null) {
                    Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة على هذا الجهاز", Toast.LENGTH_LONG).show();
                    return;
                }
                String title = (jobName == null || jobName.trim().isEmpty()) ? "POS7" : jobName.trim();
                PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(new PrintAttributes.MediaSize("POS7_80MM", "80 mm thermal", 3150, 11000))
                    .setResolution(new PrintAttributes.Resolution("POS7_203DPI", "203 dpi", 203, 203))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                    .build();
                manager.print(title, view.createPrintDocumentAdapter(title), attributes);
            }
        });
        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
        if (requestCode == BLUETOOTH_ENABLE_REQUEST) {
            boolean retry = pickAfterBluetoothEnable && resultCode == RESULT_OK;
            pickAfterBluetoothEnable = false;
            if (retry) withBluetoothPermission(() -> showBondedPrinterPicker(true));
            else notifyJsPrinterResult("disabled", "لم يتم تفعيل Bluetooth");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        stopPrinterDiscovery();
        if (bluetoothReceiverRegistered && bluetoothReceiver != null) {
            try { unregisterReceiver(bluetoothReceiver); } catch (IllegalArgumentException ignored) { }
            bluetoothReceiverRegistered = false;
        }
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        for (WebView printView : printWebViews) { printView.stopLoading(); printView.destroy(); }
        printWebViews.clear();
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
