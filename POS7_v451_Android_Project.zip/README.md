# POS7 v451 — APK تجريبي ببيانات جديدة

يتضمن هذا المشروع نسخة POS7 HTML داخل تطبيق Android WebView. في أول تشغيل لنسخة v451 تُمسح مفاتيح POS7 المحلية مرة واحدة، ثم يبدأ المخزون والفواتير والسندات فارغًا. رقم فاتورة البيع التالي يبدأ من SAL-000001 بحسب تسلسل البرنامج.

## بناء APK

افتح المجلد في Android Studio مع Android SDK 35 وJDK 17، ثم نفذ:

```bash
gradle assembleDebug
```

يظهر الملف الناتج في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

أو ارفع المجلد إلى مستودع GitHub وشغّل الإجراء اليدوي **Build POS7 v451 APK**، ثم نزّل artifact باسم `POS7-v451-fresh-debug-apk`.

الحزمة الحالية غير موقعة للنشر على Google Play؛ إنها APK debug للتثبيت التجريبي.
