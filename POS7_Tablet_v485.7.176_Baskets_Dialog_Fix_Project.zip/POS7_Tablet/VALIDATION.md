# Validation176
Source HTML matches delivered176 byte for byte. Native Java/resources/manifest unchanged from172/165. YAML and shell syntax validated. Inline JavaScript syntax validated by ci/validate.py. Original signing certificate is required and checked in CI before and after build. No local signed APK or device installation test: original secrets are not available locally.
