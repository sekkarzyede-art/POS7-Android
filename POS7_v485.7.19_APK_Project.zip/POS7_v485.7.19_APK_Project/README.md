# POS7 v485.7.19 — Android APK project

This Android WebView project packages the v485.7.19 HTML app in `app/src/main/assets/index.html`.

## Build with GitHub Actions

1. Upload `POS7_v485.7.19_APK_Project.zip` to the root of the POS7 repository, or upload the extracted project folder.
2. Copy `main.yml` to `.github/workflows/main.yml` in that repository.
3. Confirm these repository Actions secrets exist: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`.
4. Open **Actions**, run **Build POS7 v485.7.19 APK**, then download artifact `POS7-v485.7.19-release-update-apk`.

The package ID remains `com.sokkarzeyedeh.pos7`; `versionCode` is `4850719` and `versionName` is `485.7.19`. Use the same release keystore as the installed POS7 app to install as an update and preserve app data.
