package com.sokkarzeyedeh.pos7;

import android.app.Activity;
import android.app.AlertDialog;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import org.json.JSONObject;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** Native, bounded enrollment flow. Does not expose arbitrary signing to JavaScript. */
public final class Pos7EnrollmentBridge {
    private static final String ENDPOINT = "https://jdcolkgzwqpwbfvcrdje.supabase.co/functions/v1/pos7-device-enrollment";
    private final Activity activity;
    private final WebView view;
    private boolean running;
    public Pos7EnrollmentBridge(Activity activity, WebView view) { this.activity=activity; this.view=view; }

    @JavascriptInterface public void enroll(String accessToken, String deviceName) {
        // Android invokes JavascriptInterface methods on a private background thread.
        // WebView.getUrl() must be read on the main UI thread.
        activity.runOnUiThread(() -> enrollOnUiThread(accessToken, deviceName));
    }

    private synchronized void enrollOnUiThread(String accessToken, String deviceName) {
        // This bridge is only allowed for the bundled local POS7 page, not remote navigation.
        String current=view.getUrl();
        if (current==null || !current.equals("file:///android_asset/index.html")) { result("error","UNTRUSTED_PAGE"); return; }
        if (running) { result("error","ENROLLMENT_BUSY"); return; }
        if (accessToken==null || accessToken.length()<50 || accessToken.length()>8192 ||
                deviceName==null || deviceName.length()<1 || deviceName.length()>80) { result("error","INVALID_INPUT"); return; }
        // JavascriptInterface is exposed to frames as well as the top-level page.
        // Require explicit, native, user-visible consent before any device key is used.
        running=true;
        final String token=accessToken;
        final String name=deviceName;
        new AlertDialog.Builder(activity)
                .setTitle("تسجيل هذا التاب")
                .setMessage("هل توافق على بدء تسجيل هذا الجهاز في متجر POS7؟ سيُستخدم مفتاح الجهاز الآمن لإثبات هويته، وسيبقى بانتظار موافقة مدير مستقل.")
                .setNegativeButton("إلغاء", (dialog, which) -> {
                    synchronized (Pos7EnrollmentBridge.this) { running=false; }
                    result("cancelled", "أُلغي طلب تسجيل الجهاز");
                })
                .setOnCancelListener(dialog -> {
                    synchronized (Pos7EnrollmentBridge.this) { running=false; }
                    result("cancelled", "أُلغي طلب تسجيل الجهاز");
                })
                .setPositiveButton("موافق، ابدأ التسجيل", (dialog, which) -> {
                    if (!"file:///android_asset/index.html".equals(view.getUrl())) {
                        synchronized (Pos7EnrollmentBridge.this) { running=false; }
                        result("error", "UNTRUSTED_PAGE");
                        return;
                    }
                    startEnrollment(token, name);
                })
                .show();
    }

    private void startEnrollment(final String token, final String name) {
        new Thread(() -> {
            try {
                String pub=Pos7DeviceIdentity.getOrCreatePublicKeyBase64();
                JSONObject begin=post(token,new JSONObject().put("action","begin").put("deviceName",name).put("publicKeySpkiBase64",pub));
                String deviceId=begin.getString("deviceId");
                String challengeId=begin.getString("challengeId");
                long expires=begin.getLong("expiresAt");
                String nonce=begin.getString("nonce");
                String message=begin.getString("message");
                // Reject malformed or unbounded server values before accessing the device key.
                if (!deviceId.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}") ||
                    !challengeId.matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}") ||
                    !nonce.matches("[A-Za-z0-9_-]{43}") || message.length() > 350 ||
                    expires <= System.currentTimeMillis() ||
                    expires > System.currentTimeMillis() + 120000L)
                    throw new SecurityException("INVALID_SERVER_CHALLENGE");
                // User identity is obtained from the verified server message; never supplied by the WebView.
                String[] fields=message.split("\n",-1);
                if(fields.length!=6 || !"pos7-enroll-v1".equals(fields[0]) ||
                   !"register".equals(fields[1]) ||
                   !deviceId.equals(fields[2]) || !nonce.equals(fields[5]) ||
                   !fields[3].matches("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}") ||
                   expires!=Long.parseLong(fields[4])) throw new SecurityException("CHALLENGE_MISMATCH");
                String signature=Pos7EnrollmentSigner.signVerifiedFormat(message,deviceId,fields[3],System.currentTimeMillis());
                JSONObject proof=post(token,new JSONObject().put("action","prove").put("deviceId",deviceId)
                        .put("challengeId",challengeId).put("expiresAt",expires).put("nonce",nonce)
                        .put("signatureDerBase64",signature));
                if (!proof.optBoolean("verified",false)) throw new SecurityException("PROOF_NOT_VERIFIED");
                result("pending", "تم إثبات هوية الجهاز؛ بانتظار موافقة المدير");
            } catch(Exception e) {
                String reason = e.getMessage();
                if (reason != null && reason.startsWith("HTTP_"))
                    result("error", "فشل اتصال خدمة التسجيل: " + reason.replaceAll("[^A-Za-z0-9_:]", "").substring(0, Math.min(48, reason.replaceAll("[^A-Za-z0-9_:]", "").length())));
                else result("error", "تعذّر إكمال تسجيل الجهاز؛ تحقق من تفعيل الخدمة");
            }
            finally { synchronized(Pos7EnrollmentBridge.this) { running=false; } }
        },"pos7-enrollment").start();
    }

    private JSONObject post(String jwt, JSONObject body) throws Exception {
        HttpURLConnection conn=(HttpURLConnection)new URL(ENDPOINT).openConnection();
        conn.setRequestMethod("POST"); conn.setConnectTimeout(12000); conn.setReadTimeout(15000);
        conn.setDoOutput(true); conn.setInstanceFollowRedirects(false);
        conn.setRequestProperty("Authorization","Bearer "+jwt);
        conn.setRequestProperty("Content-Type","application/json");
        conn.setRequestProperty("Accept","application/json");
        byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);
        if(bytes.length>12000) throw new IllegalArgumentException("REQUEST_TOO_LARGE");
        try {
            try(OutputStream stream=conn.getOutputStream()){stream.write(bytes);}
            int code=conn.getResponseCode();
            InputStream stream=code>=400?conn.getErrorStream():conn.getInputStream();
            if(stream==null) throw new java.io.IOException("HTTP_"+code);
            byte[] data=new byte[16385]; int total=0,n;
            try(InputStream input=stream){while((n=input.read(data,total,Math.min(4096,16385-total)))>0){total+=n;if(total>=16385)throw new java.io.IOException("RESPONSE_TOO_LARGE");}}
            JSONObject response=new JSONObject(new String(data,0,total,StandardCharsets.UTF_8));
            if(code<200 || code>=300) throw new java.io.IOException("HTTP_"+code+":"+response.optString("error","SERVICE_ERROR"));
            return response;
        } finally {conn.disconnect();}
    }
    private void result(String status,String message) {
        activity.runOnUiThread(()->{
            if(view.getUrl()==null || !view.getUrl().equals("file:///android_asset/index.html"))return;
            String js="if(window.pos7EnrollmentResult)window.pos7EnrollmentResult("+JSONObject.quote(status)+","+JSONObject.quote(message)+")";
            view.evaluateJavascript(js,null);
        });
    }
}
