package com.sokkarzeyedeh.pos7;

import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.MessageDigest;
import java.security.spec.ECGenParameterSpec;

/** Stage 1 only: isolated local device identity. Not exposed to WebView or network. */
public final class Pos7DeviceIdentity {
    private static final String ALIAS = "pos7_image_approval_device_p256_v1";
    private Pos7DeviceIdentity() {}

    public static synchronized String getOrCreatePublicKeyBase64() throws Exception {
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        if (!store.containsAlias(ALIAS)) {
            KeyPairGenerator generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
            KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN)
                    .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .setUserAuthenticationRequired(false)
                    .build();
            generator.initialize(spec);
            generator.generateKeyPair();
        }
        java.security.cert.Certificate certificate = store.getCertificate(ALIAS);
        if (certificate == null) throw new IllegalStateException("Missing Android Keystore certificate");
        return Base64.encodeToString(certificate.getPublicKey().getEncoded(), Base64.NO_WRAP);
    }

    /** Local self-test only: never signs caller-supplied data via the WebView bridge. */
    public static synchronized String localSelfTest() throws Exception {
        String publicKey = getOrCreatePublicKeyBase64();
        byte[] probe = "POS7_LOCAL_KEYSTORE_SELF_TEST_V1".getBytes(StandardCharsets.UTF_8);
        String signature = signChallengeForNativeApproval(probe);
        java.security.KeyFactory factory = java.security.KeyFactory.getInstance("EC");
        java.security.PublicKey key = factory.generatePublic(
                new java.security.spec.X509EncodedKeySpec(Base64.decode(publicKey, Base64.DEFAULT)));
        Signature verifier = Signature.getInstance("SHA256withECDSA");
        verifier.initVerify(key);
        verifier.update(probe);
        if (!verifier.verify(Base64.decode(signature, Base64.DEFAULT)))
            throw new SecurityException("Local signature verification failed");
        byte[] digest = MessageDigest.getInstance("SHA-256").digest(Base64.decode(publicKey, Base64.DEFAULT));
        StringBuilder fingerprint = new StringBuilder();
        for (byte b : digest) fingerprint.append(String.format(java.util.Locale.US, "%02X", b & 0xff));
        return fingerprint.toString();
    }

    /** Sign only a server-issued, validated challenge in a future security-reviewed integration. */
    static synchronized String signChallengeForNativeApproval(byte[] challenge) throws Exception {
        if (challenge == null || challenge.length == 0 || challenge.length > 4096)
            throw new IllegalArgumentException("Invalid challenge length");
        getOrCreatePublicKeyBase64();
        KeyStore store = KeyStore.getInstance("AndroidKeyStore");
        store.load(null);
        PrivateKey privateKey = (PrivateKey) store.getKey(ALIAS, null);
        if (privateKey == null) throw new IllegalStateException("Missing private key");
        Signature signer = Signature.getInstance("SHA256withECDSA");
        signer.initSign(privateKey);
        signer.update(challenge);
        return Base64.encodeToString(signer.sign(), Base64.NO_WRAP);
    }
}
