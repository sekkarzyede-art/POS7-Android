package com.sokkarzeyedeh.pos7;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;

/** STAGING ONLY. Native validation of enrollment challenge before Keystore signing.
 * Caller must also verify trusted WebView origin and authenticated server response.
 */
final class Pos7EnrollmentSigner {
    private static final Pattern UUID = Pattern.compile("[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}");
    private static final Pattern NONCE = Pattern.compile("[A-Za-z0-9_-]{43}");
    private static final Set<String> signed = new HashSet<>();
    private Pos7EnrollmentSigner() {}

    static synchronized String signVerifiedFormat(String message, String expectedDeviceId, String expectedUserId, long nowMs) throws Exception {
        if (expectedDeviceId == null || expectedUserId == null) throw new SecurityException("missing trusted identity");
        if (message == null || message.length() > 350) throw new SecurityException("invalid message size");
        String[] fields = message.split("\\n", -1);
        if (fields.length != 6 || !"pos7-enroll-v1".equals(fields[0]) || !"register".equals(fields[1])
                || !UUID.matcher(fields[2]).matches() || !UUID.matcher(fields[3]).matches()
                || !NONCE.matcher(fields[5]).matches()
                || !expectedDeviceId.equalsIgnoreCase(fields[2])
                || !expectedUserId.equalsIgnoreCase(fields[3])) throw new SecurityException("invalid enrollment message");
        long expires;
        try { expires = Long.parseLong(fields[4]); } catch (NumberFormatException ex) { throw new SecurityException("invalid expiry"); }
        if (expires <= nowMs || expires > nowMs + 120000L) throw new SecurityException("expired or overlong challenge");
        // Prevent a local duplicate signing of the same challenge. Process-memory scope only.
        String unique = fields[2] + ":" + fields[5];
        if (signed.contains(unique)) throw new SecurityException("challenge already signed");
        // Fail before any Keystore signing when the bounded replay cache is full.
        if (signed.size() >= 128) throw new SecurityException("signing cache full; restart enrollment");
        String signature = Pos7DeviceIdentity.signChallengeForNativeApproval(message.getBytes(StandardCharsets.UTF_8));
        signed.add(unique);
        return signature;
    }
}
