POS7 v485.7.208 — Enrollment Preflight Fix (STAGING)

Implemented: validate server challenge UUID-shaped IDs, nonce length, bounded expiry and message length BEFORE Keystore signing; show sanitized HTTP error codes.
Checked: package ID and version unchanged; Android enrollment bridge exists; native confirmation retained; accounting sync files untouched.
Not done: APK build (Gradle/Android SDK unavailable in this environment); Supabase deployment; device enrollment; image approval.
Do NOT install or deploy as production. Original signing key required for release build.
