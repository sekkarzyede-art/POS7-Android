const fs=require('fs'), assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const java=fs.readFileSync('app/src/main/java/com/sokkarzeyedeh/pos7/MainActivity.java','utf8');
assert(html.includes("POS7_APP_VERSION='485.7.187'"));
for(const method of ['getBackupFolderStatus','saveScheduledBackup','pos7OnScheduledBackupResult']){
  assert(html.includes(method),`Missing HTML: ${method}`);
  assert(java.includes(method),`Missing Java: ${method}`);
}
assert(html.includes('النسخ التلقائي داخل التطبيق'));
assert(java.includes('DriveBackupManager.validate(saved)'));
const writeBlock=java.slice(java.indexOf('private void writeBackupToTree('), java.indexOf('private void pruneScheduledBackup('));
assert(writeBlock.includes('catch (Exception invalidBackup)'));
assert(writeBlock.includes('throw new IOException('));
assert(java.includes('pruneScheduledBackup'));
console.log('Backup folder status + automatic external backup wiring verified');
