const fs=require('fs'),assert=require('assert');
const html=fs.readFileSync('app/src/main/assets/index.html','utf8');
const gradle=fs.readFileSync('app/build.gradle','utf8');
assert(html.includes("POS7_APP_VERSION='485.7.187'"));
assert(gradle.includes("versionName '485.7.187'"));
assert(!html.includes('POS7_HTML_READONLY_PREVIEW'),'Never bundle read-only browser preview in Android APK');
for(const term of ['pos185-invoice-save-diagnostics','pos185Diag','function diagnose(kind,fn,ctx,args)','function wrapSave(name,kind)','wrapSave(\'saveSale\',\'بيع\')','wrapSave(\'savePurchase\',\'شراء\')','pos185SerializationStart','pos185Clock'])assert(html.includes(term),term);
for(const term of ['pos181Fingerprint','pos177SyncDiagnostics','saveScheduledBackup','pos7OnScheduledBackupResult','pos183-backup-location-style'])assert(html.includes(term),term);
console.log('PASS production diagnostics, invoice wrappers, backup and sync markers');
