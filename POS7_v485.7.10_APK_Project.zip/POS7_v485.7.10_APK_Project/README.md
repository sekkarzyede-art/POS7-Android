# POS7 v485.7.10 — Android APK project

This Android WebView project packages the v485.7.10 HTML app. Its product-selection sound is embedded in `app/src/main/assets/index.html`, so it works offline without a separate audio file.

## Build with GitHub Actions

1. Upload `POS7_v485.7.10_APK_Project.zip` to the root of the POS7 repository, or upload this extracted project folder.
2. Copy `main.yml` to `.github/workflows/main.yml` in the repository.
3. Confirm the four repository Actions secrets exist: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`.
4. Open **Actions**, run **Build POS7 v485.7.10 APK**, then download artifact `POS7-v485.7.10-release-update-apk`.

The package ID remains `com.sokkarzeyedeh.pos7`; `versionCode` is `4850710` and `versionName` is `485.7.10`. Keep the same signing keystore used for the installed POS7 APK to install this build as an update and retain its app data. The workflow verifies the package ID, version, signature, and embedded audio before publishing the artifact.
