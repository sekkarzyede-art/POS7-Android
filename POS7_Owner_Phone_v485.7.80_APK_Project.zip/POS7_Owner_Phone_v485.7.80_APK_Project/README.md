# POS7 Owner Phone v485.7.80

مشروع Android للهاتف، يتضمن أحدث نسخة HTML للتطبيق مع توزيع أزرار «استعلاماتك» بالتساوي داخل بطاقة واحدة.

- Android applicationId: `com.sokkarzeyedeh.pos7owner`
- versionName: `485.7.80`
- versionCode: `4850780` (أعلى من بناء الهاتف المسجل 4850766)
- يستخدم شهادة إصدار POS7 الحالية. لا تزل التطبيق القديم قبل تثبيت التحديث حتى تبقى بيانات الهاتف.
- انسخ ملف workflow المرفق إلى `.github/workflows/main.yml` في مستودع GitHub.
- يحتاج GitHub Actions إلى الأسرار الأربعة المحفوظة مسبقًا: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`. يتحقق سير العمل من بصمة الشهادة قبل رفع APK.
