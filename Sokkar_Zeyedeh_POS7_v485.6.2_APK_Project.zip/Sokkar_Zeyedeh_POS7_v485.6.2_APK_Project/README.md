# متجر سكر زيادة — مشروع APK v485.6.2

يحتوي هذا المشروع على واجهة POS7 نفسها المجرّبة في Chrome داخل تطبيق Android WebView. في هذا الإصدار يُحمّل التطبيق ملف HTML المضمّن من جديد عند التشغيل، ويثبت تكبير النص عند 100% لتجنب استعادة صفحة أو مقياس قديم. كما يتحقق GitHub Actions من علامة مصدر HTML قبل البناء.

- اسم التطبيق: متجر سكر زيادة
- رقم إصدار APK: 485.6.2
- مصدر الواجهة: HTML v485.6.1 دون تغيير مرئي
- `versionCode`: 487 لتثبيت التحديث فوق إصدار 485
- `applicationId`: `com.sokkarzeyedeh.pos7` (محفوظ للتحديث فوق التطبيق الحالي)
- ملفات الواجهة: `app/src/main/assets/index.html` و`Sokkar_Zeyedeh_POS7_v485.6.2_Chrome_Test.html`

## البناء من GitHub Actions

1. ارفع `Sokkar_Zeyedeh_POS7_v485.6.2_APK_Project.zip` إلى جذر مستودع GitHub على فرع `main`.
2. أنشئ الملف `.github/workflows/main.yml` والصق محتوى ملف `main.yml` المرفق.
3. أضف أسرار التوقيع الأربعة في إعدادات المستودع: `POS7_KEYSTORE_BASE64` و`POS7_KEYSTORE_PASSWORD` و`POS7_KEY_ALIAS` و`POS7_KEY_PASSWORD`.
4. من تبويب **Actions** شغّل **Build POS7 v485.6.2 APK**.
5. نزّل ملف APK من Artifact باسم `Sokkar-Zeyedeh-POS7-v485.6.2-release-update-apk`.

يجب استخدام ملف التوقيع نفسه الذي وقّع نسخة التطبيق المثبتة لتتمكن من تثبيت APK كتحديث. لم يُبنَ APK داخل هذه الحزمة؛ هذه ملفات المشروع وملف سير البناء.
