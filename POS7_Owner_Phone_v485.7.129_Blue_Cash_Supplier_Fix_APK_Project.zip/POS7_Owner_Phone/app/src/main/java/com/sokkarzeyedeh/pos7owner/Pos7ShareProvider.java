package com.sokkarzeyedeh.pos7owner;
public class Pos7ShareProvider extends androidx.core.content.FileProvider {
    public Pos7ShareProvider() { super(); }
}
