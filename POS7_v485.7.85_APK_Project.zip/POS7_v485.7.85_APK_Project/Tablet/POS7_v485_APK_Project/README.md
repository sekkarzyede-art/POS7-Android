# POS7 Tablet APK Project v485.7.85

- Application ID: `com.sokkarzeyedeh.pos7` (unchanged for in-place updates).
- Version code: `4850785`; version name: `485.7.85`.
- Includes the v485.7.85 tablet-authoritative sync page, a top-right color status light, immediate sync after successful local saves, and an automatic 15-second sync/retry cycle.
- Local saves remain available offline; cloud sync requires an owner session and internet connection.
- This build does not alter the owner phone APK or its signing configuration.

Build with the same POS7 tablet release keystore used for the installed APK. Configure GitHub Actions secrets `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The supplied workflow checks certificate SHA-256 `843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495` before and after build; a mismatch fails without uploading an APK.
