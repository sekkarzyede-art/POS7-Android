# POS7 v485.7.65 — مشروع Android للبناء والتحديث

تحتوي الحزمة على مشروع Android الكامل، ونسخة الواجهة الأخيرة داخل أصول التطبيق، ونسخة HTML للاختبار في Chrome.

## البناء عبر GitHub Actions

1. ارفع ملف `POS7_v485.7.65_Final_APK_Project.zip` إلى المستودع على فرع `main`.
2. انسخ الملف `main.yml` المرفق إلى `.github/workflows/main.yml` في المستودع.
3. تأكد من وجود أسرار التوقيع الأربعة نفسها المستخدمة في النسخة المثبتة: `POS7_KEYSTORE_BASE64` و`POS7_KEYSTORE_PASSWORD` و`POS7_KEY_ALIAS` و`POS7_KEY_PASSWORD`.
4. افتح **Actions** وشغّل **Build POS7 v485.7.65 APK**. بعد نجاح البناء نزّل artifact باسم `POS7-v485.7.65-release-update-apk`.

## التحديث والتوقيع

حافظت الحزمة على معرّف التطبيق `com.sokkarzeyedeh.pos7`، ورفعت `versionCode` إلى `486` حتى يقبل Android تثبيته كتحديث فوق بناء `485`. يجب استخدام مفتاح التوقيع نفسه الموجود في النسخة المثبتة؛ تغيير المفتاح يمنع التحديث فوقها.

هذه حزمة مشروع بناء وليست ملف APK جاهزاً. GitHub Actions ينتج APK موقّعاً باستخدام أسرار المستودع.
