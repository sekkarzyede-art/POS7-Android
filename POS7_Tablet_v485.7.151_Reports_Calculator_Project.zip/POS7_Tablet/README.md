# POS7 Tablet 485.7.151

Upload POS7_Tablet_v485.7.151_Reports_Calculator_Project.zip to the repository root. Use the supplied main.yml as .github/workflows/main.yml. Existing signing secrets are required.

This tablet app retains com.sokkarzeyedeh.pos7, the original certificate and file:///android_asset/index.html. Version caption and Android versionName: 485.7.151. Minimum versionCode: 48507510; workflow raises it using the run number or installed_version_code input.

Reports load 20 rows at a time, preserving complete totals/print sources. Period buttons: today/current month/current year. Floating calculator toggles next to the alert bell.

Native wrapper and dependencies retained from startup-fixed v130. No cloud/SQL deployment is required. Existing phone Firebase integration is unchanged. Do not uninstall the existing app to update.
