# POS7 v475 — مشروع Android لبناء APK مع أيقونة المتجر

يضم التطبيق نسخة POS7 v475 مع البحث عن طابعات Bluetooth القريبة وبدء اقترانها من داخل التطبيق، وطلب أذونات الأجهزة القريبة قبل المسح والاتصال. اختيار الطابعة المقترنة محفوظ للاستخدام لاحقًا. يحافظ التطبيق كذلك على تحسينات استقرار الطباعة المباشرة، وأيقونة «سكر زيادة» واسم التطبيق «متجر سكر زيادة». معرّف التطبيق محفوظ كي يمكن تثبيته كتحديث فوق التطبيق السابق.

## تغيير الأيقونة لاحقًا

استبدل الصورة `app/src/main/res/mipmap-nodpi/ic_launcher.jpg`، واستبدل أيضًا `app/src/main/res/drawable-nodpi/ic_launcher_foreground.jpg` بالصورة الجديدة. اترك أسماء الملفات كما هي، ثم أعد بناء APK. اسم التطبيق أسفل الأيقونة يتغير من `app/src/main/AndroidManifest.xml` عند `android:label`.

## بناء APK عبر GitHub Actions

1. ارفع `POS7_v475_APK_Project.zip` إلى جذر مستودع GitHub.
2. ضع محتوى `POS7_v475_main.yml` في المسار `.github/workflows/main.yml`.
3. افتح **Actions** وشغّل **Build POS7 v475 APK** إذا لم يبدأ تلقائيًا.
4. بعد النجاح نزّل artifact باسم `POS7-v475-apk`، ثم فك ضغطه لتحصل على `app-debug.apk`.

يتطلب البناء المحلي JDK 17 وAndroid SDK 35 وGradle 8.9. الناتج APK تجريبي debug وليس نسخة موقعة للنشر في Google Play.
