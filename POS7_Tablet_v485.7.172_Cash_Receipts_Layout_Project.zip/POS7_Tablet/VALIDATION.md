# Source verification485.7.172
HTML172:298 inline JavaScript blocks passed node syntax validation. Targeted regression mocks covered duplicate cash rows, USD denomination, cash-only HTML and canvas receipts, detailed credit/purchase receipts. Prior171 tests covered add forms, calendar-month range, expense totals and six cash adjustment accounts.
Native Java/manifest/resources/dependencies unchanged from165; WebView storage origin unchanged. Gradle versionName/code updated only. ZIP integrity and workflow/source agreement checked.
No signed APK compiled locally: original signing credentials remain in GitHub Secrets. CI must compile and verify signer/package/version. Device update, visual layout, physical printer, Drive and notifications require device validation.
