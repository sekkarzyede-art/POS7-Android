# POS7 Tablet 485.7.172
Cumulative HTML172 with unchanged native165 wrapper. Original applicationId com.sokkarzeyedeh.pos7 and file:///android_asset/index.html storage origin are retained. Native split-screen resize/resume protection, independent SAF backups (latest20), Drive, sharing, printing and cloud integrations are preserved.

Upload POS7_Tablet_v485.7.172_Cash_Receipts_Layout_Project.zip to the root of the existing POS7-Android repository. Put the accompanying main.yml at .github/workflows/main.yml. Retain original POS7 signing secrets; no new signing key. Do not use Branch2 unless it has the same original signing secrets and is intentionally the target.

GitHub Actions checks original signing fingerprint before build and verifies package, version and APK signer afterward. Missing/wrong signing credentials stop the build. Download signed APK from the successful build artifact. Do not uninstall the existing application.

Minimum versionCode48507720. Workflow chooses max(48507720, installed_version_code+1,48507719+run_number). For an installed code above the default, enter its actual numeric versionCode in Run workflow. versionName is not versionCode.

UI172: duplicate synthetic legacy cash rows suppressed when ledger holds invoice; financial cards; three-column absent-client cards; per-invoice cash-only print preference; add-item button layout. Includes166–171 changes. Cash-only printing affects presentation, not financial values. Credit invoices retain details.

Logo runs for five seconds while startup runs underneath; same live document is retained on native resize/resume. Process death can still reload the document. No guarantee of indefinite process residency. No data-clearing migration.

This delivery is APK build source, not a compiled APK. Local JavaScript/source checks do not substitute for GitHub Android compilation or physical device printing/Drive/update validation.
