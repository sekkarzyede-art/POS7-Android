# POS7 v470 — مشروع Android لبناء APK

يحتوي هذا المشروع على نسخة POS7 v470 داخل تطبيق Android WebView، مع الحفاظ على معرّف التطبيق نفسه لتثبيت النسخة كتحديث فوق التطبيق السابق.

## بناء APK عبر GitHub Actions

1. ارفع `POS7_v470_APK_Project.zip` إلى جذر مستودع GitHub.
2. أنشئ المسار `.github/workflows/main.yml` والصق محتوى ملف `POS7_v470_main.yml`.
3. بعد حفظ الملفات افتح تبويب **Actions**، ثم شغّل **Build POS7 v470 APK** إذا لم يبدأ تلقائيًا.
4. بعد نجاح البناء افتح نتيجة التشغيل ونزّل artifact باسم `POS7-v470-apk`، ثم فك ضغطه لتحصل على `app-debug.apk`.

يمكن أيضًا فتح المجلد في Android Studio أو بناؤه باستخدام JDK 17 وAndroid SDK 35 وGradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

الناتج: `app/build/outputs/apk/debug/app-debug.apk`.

هذا APK تجريبي debug وليس إصدارًا موقّعًا للنشر في Google Play.
