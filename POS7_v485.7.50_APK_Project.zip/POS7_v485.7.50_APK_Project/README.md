# مشروع POS7 APK — النسخة 485.7.50

يضم هذا المشروع تطبيق Android WebView مع نسخة HTML v485.7.50 داخل `app/src/main/assets/index.html`. تتضمن النسخة بطاقة أرباح المالك الشهرية وزر التحويل الفوري وإصلاح فتح المحفظة من أعلى الصفحة.

## البناء عبر GitHub Actions

1. ارفع `POS7_v485.7.50_APK_Project.zip` إلى جذر مستودع POS7، أو ارفع مجلد المشروع بعد فك الضغط.
2. انسخ ملف `POS7_v485.7.50_main.yml` إلى `.github/workflows/main.yml` داخل المستودع.
3. تأكد من وجود أسرار التوقيع الأربعة في إعدادات Actions: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`.
4. من تبويب **Actions** شغّل **Build POS7 v485.7.50 APK**، ثم نزّل artifact باسم `POS7-v485.7.50-release-update-apk`.

## التحديث فوق التطبيق الحالي

يحافظ المشروع على `applicationId` نفسه `com.sokkarzeyedeh.pos7` ويرفع `versionCode` إلى `4850750` و`versionName` إلى `485.7.50`. يجب استخدام keystore وalias وكلمات المرور نفسها التي وُقّعت بها النسخة المثبتة؛ تغييرها يمنع تثبيت APK فوق التطبيق القديم. لا يمسح المشروع بيانات التطبيق.
