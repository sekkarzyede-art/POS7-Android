#!/usr/bin/env python3
"""Conservative patch for original POS7 owner phone MainActivity.java.
Does not touch sync, Firebase, push service, or existing JS bridge.
Fails closed if original WebChromeClient structure differs.
"""
from pathlib import Path
import re
p=Path('android-project/POS7_Owner_Phone/app/src/main/java/com/sokkarzeyedeh/pos7owner/MainActivity.java')
if not p.is_file(): raise SystemExit('Original MainActivity.java not found')
s=p.read_text('utf-8')
if 'POS7_R53_CAMERA_CAPTURE' in s:
    print('Camera patch already applied')
    raise SystemExit(0)
if 'onShowFileChooser' in s:
    raise SystemExit('Existing onShowFileChooser found: manual review required, no unsafe overwrite')
# Insert override in anonymous WebChromeClient, retaining all original handlers.
pattern=r'(setWebChromeClient\s*\(\s*new\s+(?:android\.webkit\.)?WebChromeClient\s*\(\s*\)\s*\{)'
match=list(re.finditer(pattern,s))
if len(match)!=1:
    raise SystemExit(f'Expected exactly one anonymous WebChromeClient, found {len(match)}; stop without altering app')
# Avoid collisions with existing activity results.
if re.search(r'\bvoid\s+onActivityResult\s*\(',s):
    raise SystemExit('Existing onActivityResult requires manual merge; stop to preserve native behavior')
fields='''
    // POS7_R53_CAMERA_CAPTURE: temporary image URI and WebView file selection callback.
    private android.webkit.ValueCallback<android.net.Uri[]> pos7R53FileCallback;
    private android.net.Uri pos7R53CameraUri;
    private static final int POS7_R53_CAMERA_REQUEST = 53144;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {
        if (requestCode == POS7_R53_CAMERA_REQUEST) {
            android.webkit.ValueCallback<android.net.Uri[]> cb = pos7R53FileCallback;
            pos7R53FileCallback = null;
            android.net.Uri captured = pos7R53CameraUri;
            pos7R53CameraUri = null;
            if (cb != null) {
                if (resultCode == android.app.Activity.RESULT_OK && captured != null) {
                    cb.onReceiveValue(new android.net.Uri[]{captured});
                } else {
                    if (captured != null) try { getContentResolver().delete(captured, null, null); } catch (Exception ignored) {}
                    cb.onReceiveValue(null);
                }
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
'''
# Locate class opening, ensure it's the activity class (not nested).
class_match=re.search(r'\bclass\s+MainActivity\b[^\{]*\{',s)
if not class_match: raise SystemExit('MainActivity class declaration missing')
s=s[:class_match.end()]+fields+s[class_match.end():]
# Find WebChromeClient again after insertion
m=re.search(pattern,s)
method='''
            // POS7_R53_CAMERA_CAPTURE: honor HTML capture=environment in Android APK.
            @Override
            public boolean onShowFileChooser(android.webkit.WebView webView,
                    android.webkit.ValueCallback<android.net.Uri[]> filePathCallback,
                    android.webkit.WebChromeClient.FileChooserParams fileChooserParams) {
                if (pos7R53FileCallback != null) {
                    pos7R53FileCallback.onReceiveValue(null);
                    pos7R53FileCallback = null;
                }
                if (fileChooserParams == null || !fileChooserParams.isCaptureEnabled()) {
                    // Preserve Android's normal chooser for other file inputs.
                    try {
                        android.content.Intent chooser = fileChooserParams != null
                            ? fileChooserParams.createIntent()
                            : new android.content.Intent(android.content.Intent.ACTION_GET_CONTENT)
                                .setType("image/*").addCategory(android.content.Intent.CATEGORY_OPENABLE);
                        pos7R53FileCallback = filePathCallback;
                        startActivityForResult(chooser, POS7_R53_PICK_REQUEST);
                        return true;
                    } catch (Exception e) {
                        pos7R53FileCallback = null;
                        return false;
                    }
                }
                try {
                    android.content.ContentValues values = new android.content.ContentValues();
                    values.put(android.provider.MediaStore.Images.Media.DISPLAY_NAME,
                        "POS7_" + System.currentTimeMillis() + ".jpg");
                    values.put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                    android.net.Uri uri = getContentResolver().insert(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    android.content.Intent camera = new android.content.Intent(
                        android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    camera.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, uri);
                    camera.putExtra("android.intent.extras.CAMERA_FACING", 0);
                    camera.putExtra("android.intent.extra.USE_FRONT_CAMERA", false);
                    camera.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION |
                        android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    camera.setClipData(android.content.ClipData.newRawUri("POS7 photo", uri));
                    pos7R53CameraUri = uri;
                    pos7R53FileCallback = filePathCallback;
                    startActivityForResult(camera, POS7_R53_CAMERA_REQUEST);
                    return true;
                } catch (Exception e) {
                    if (pos7R53CameraUri != null) {
                        try { getContentResolver().delete(pos7R53CameraUri, null, null); }
                        catch (Exception ignored) {}
                    }
                    pos7R53CameraUri = null;
                    pos7R53FileCallback = null;
                    return false;
                }
            }
'''
# add separate picker request handling, preserve selected Uri via standard WebChromeClient parser.
s=s.replace('private static final int POS7_R53_CAMERA_REQUEST = 53144;', 'private static final int POS7_R53_CAMERA_REQUEST = 53144;\n    private static final int POS7_R53_PICK_REQUEST = 53145;')
s=s.replace('if (requestCode == POS7_R53_CAMERA_REQUEST) {','if (requestCode == POS7_R53_PICK_REQUEST) {\n            android.webkit.ValueCallback<android.net.Uri[]> cb = pos7R53FileCallback;\n            pos7R53FileCallback = null;\n            if (cb != null) cb.onReceiveValue(android.webkit.WebChromeClient.FileChooserParams.parseResult(resultCode, data));\n            return;\n        }\n        if (requestCode == POS7_R53_CAMERA_REQUEST) {')
m=re.search(pattern,s)
s=s[:m.end()]+method+s[m.end():]
p.write_text(s,'utf-8')
assert s.count('POS7_R53_CAMERA_CAPTURE')>=2
print('Patched native WebChromeClient camera capture; preserved original MainActivity and FCM')
