# POS7 — سجل استمرارية R53 — 10 نوفمبر 2026

## المرجع المعتمد
- تطبيق هاتف المالك الصحيح: `POS7_OWNER_PHONE_v485.7.143_SIGNED.apk`، تم التأكد من تطابق واجهته مع التطبيق الذي لدى المستخدم.
- النسخة المستهدفة: `v485.7.144 R53`، الحزمة `com.sokkarzeyedeh.pos7owner`.
- مصدر Android الأصلي في GitHub: `POS7_Phone_v485.7.136_Photos_Android_Project.zip`.
- لا تعديل على التاب R51 أو Supabase.

## سبب فشل GitHub Actions #176
فشل خطوة `Verify Android camera chooser before release` لأن `MainActivity.java` لا يحتوي `onShowFileChooser` و`ACTION_IMAGE_CAPTURE`؛ أوقف فحص الأمان البناء قبل التوقيع. لا دليل على فشل التوقيع أو Firebase.

## ملفات الإصلاح الجديدة
- `POS7_Phone_v485.7.144_R53_main_FIXED.yml`: يستخرج المشروع الأصلي، يدمج HTML، ويحقن تعديلًا محافظًا في `MainActivity.java` قبل فحص الكاميرا، ثم يبني APK باستخدام أسرار GitHub الأصلية.
- `POS7_Phone_v485.7.144_R53_HTML_OVERLAY_FIXED.zip`: واجهة R52 مع تصحيح `<title>` إلى `v485.7.144`.
- `POS7_R53_PATCH_MAINACTIVITY.py`: سكربت الإصلاح المستقل للمراجعة؛ يضيف `WebChromeClient.onShowFileChooser` و`onActivityResult` لالتقاط الصور عبر `MediaStore.ACTION_IMAGE_CAPTURE`، ويحافظ على وظائف Android الأخرى، ويوقف التعديل إن اختلف هيكل الكود أو كان هناك معالج نتائج موجود.

## الحماية
- لا تغيير لأسماء أسرار التوقيع `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`.
- الاحتفاظ بأولوية `POS7_FIREBASE_JSON_BASE64` كما في workflow السابق، مع بدائله الموجودة مسبقًا.
- التحقق من بصمة شهادة التوقيع `843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495`.
- `versionName=485.7.144`، و`versionCode` أعلى وفق آلية workflow السابقة.
- الحفاظ على خدمة `Pos7MessagingService.java` وإعدادات Firebase وعدم تغيير البيانات المحلية.

## حالة التحقق
- فُحصت بنية YAML والـ HTML ZIP، ونجح اختبار موضعي للسكريبت على نموذج MainActivity مبسط.
- **لم يُشغّل البناء على GitHub ولم يُنتَج APK موقّع حتى الآن.** يلزم وضع ملفي workflow وoverlay في المستودع ثم تشغيل Actions وفحص سجل البناء واختبار الكاميرا على الجهاز.
- سكربت الإصلاح يتوقف عمدًا إذا كانت بنية `MainActivity` غير متوقعة، بدل حذف وظائف قائمة.

## الخطوة التالية
رفع `POS7_Phone_v485.7.144_R53_main_FIXED.yml` باسم `.github/workflows/main.yml` ورفع `POS7_Phone_v485.7.144_R53_HTML_OVERLAY_FIXED.zip` باسم `POS7_Phone_v485.7.144_R53_HTML_OVERLAY.zip` ثم تشغيل GitHub Actions. عند الفشل إرسال صورة السطر الأحمر؛ عند النجاح تنزيل artifact وتثبيته فوق النسخة الموجودة دون إلغاء تثبيت التطبيق.

**المتبقي تقديريًا 5–15% حسب نتائج بناء Android واختبار الجهاز.**
