# POS7 Tablet 485.7.130 — إعداد Google Drive

هذه النسخة مبنية على HTML ومشروع Android للنسخة الناجحة 485.7.104.

## طريقة الاستخدام

1. الموردون ← عرض الموردين ← المورد ← تفاصيل: اختر «من–إلى» ثم «عرض كشف الحساب».
2. من «النسخة الاحتياطية» اضغط «حفظ نسخة إلى Google Drive». أول استخدام يطلب اختيار حساب Google والموافقة. يمكنك اختيار Gmail نفسه المستخدم لحساب المزامنة؛ موافقة Drive منفصلة عن دخول المزامنة الحالي.
3. تُحفظ كل نسخة كملف JSON جديد داخل مجلد **POS7 Backups**. لا تُحذف النسخ السابقة ولا يتغير سجل المتجر بسبب الرفع.
4. «تنزيل آخر نسخة من Google Drive» يجلب أحدث نسخة أنشأها هذا التطبيق في الحساب المحدد، ويتحقق من سلامتها ثم يحفظها في مجلد النسخ المختار، أو يطلب منك مكان الحفظ.
5. لاستعادة بياناتها: اضغط «استعادة نسخة» واختر الملف المحفوظ. قواعد التأكيد وكلمة مرور الاستعادة الحالية باقية. تنزيل الملف وحده لا يستبدل البيانات.
6. «إرسال النسخة عبر واتساب» يفتح مشاركة Android. اختر واتساب، ثم المستلم، ثم أرسل الملف. فتح نافذة المشاركة لا يعني أن الملف أُرسل.

لا يظهر تسجيل Drive عند فتح التطبيق. الحفظ إلى Drive يدوي، والجدول المحلي الحالي 09:00 / 13:00 / 16:00 باقٍ كما هو. النسخة تشمل بيانات المتجر الموجودة في كائن النسخ المعتمد، ولا تشمل جلسات Google أو Supabase أو إعدادات Android أو الفاتورة غير المحفوظة. حد نقل Drive ومشاركة الملف 50 MiB؛ الحفظ المحلي الحالي متاح.

## إعداد Google Cloud مرة واحدة قبل تجربة Drive

هذا الإعداد لم يُنفذ على حسابك من هنا. لا يلزم تغيير Firebase أو قاعدة Supabase.

1. افتح https://console.cloud.google.com/ واختر مشروع Google الذي ستستخدمه دائمًا لهذا التطبيق.
2. من APIs & Services فعّل **Google Drive API**.
3. في Google Auth Platform أكمل Branding ومعلومات التطبيق، وحدد الجمهور المناسب. عند وضع Testing أضف بريد مالك المتجر ضمن Test users. موافقات الاختبار قد تحتاج تجديدًا؛ عند الاستخدام الدائم راجع نشر التطبيق ومتطلبات Google المعروضة لحسابك.
4. في Clients أنشئ **OAuth client من نوع Android**، بالقيم التالية:

   - Package name: `com.sokkarzeyedeh.pos7`
   - SHA-1 للشهادة الأصلية: `DD:50:6B:27:B1:80:EF:7A:12:01:4E:4E:E4:F6:BC:4E:2D:1E:8A:08`

5. الصلاحية المستخدمة: `https://www.googleapis.com/auth/drive.file` — الملفات التي أنشأها التطبيق أو أُتيحت له، وليس كل ملفات Drive.
6. لا يحتاج هذا التنفيذ إلى client secret داخل البرنامج، أو مفتاح service account، أو حساب Google جديد. لا ترسل كلمة مرور Google.
7. ثبّت APK الموقّع من البناء، وافتح بطاقة النسخ واضغط الحفظ. يجب وجود خدمات Google Play وحساب Google واتصال إنترنت.

الربط الأصلي يتم عبر Google Play services وAuthorizationClient. لا تُرسل رموز Google إلى JavaScript أو Supabase. زر «فصل Google Drive» يسحب الموافقة مع إبقاء الملفات السابقة في حسابك. احتفظ بمشروع Google Cloud نفسه للوصول إلى نسخ التطبيق من جهاز احتياطي بنفس التطبيق والحساب.

## بناء APK باستخدام GitHub

ارفع `POS7_Tablet_v485.7.130_APK_Project.zip` إلى جذر المستودع، وضع محتوى `POS7_Tablet_v485.7.130_main.yml` في `.github/workflows/main.yml`.

الأسرار الأربعة الأصلية باقية:

- `POS7_KEYSTORE_BASE64`
- `POS7_KEYSTORE_PASSWORD`
- `POS7_KEY_ALIAS`
- `POS7_KEY_PASSWORD`

البناء يتوقف إذا اختلفت شهادة التوقيع عن الأصل، ولا ينشئ توقيعًا جديدًا. رقم versionCode يرتفع اعتمادًا على رقم تشغيل Actions. إذا كان APK المثبت يحمل versionCode أعلى، أدخله في حقل `installed_version_code` عند تشغيل Actions يدويًا. اسم النسخة الظاهر وحده لا يكفي لمعرفة versionCode.

لا تحذف التطبيق المثبت بغرض التحديث. توافق التحديث يتطلب نفس الحزمة والشهادة ورقم versionCode أعلى من المثبت. لم يُنتج APK موقّع هنا لأن مفتاحك الخاص موجود في أسرار GitHub.

## حدود التجربة

HTML المحلي يختبر كشف المورد والواجهة والحفظ المحلي. ربط Drive ومشاركة Android يحتاجان APK وإعداد Google السابق. لا تُعد الاختبارات البرمجية إثباتًا لنجاح الرفع أو الاستعادة على جهازك؛ اختبرها على بيانات تجريبية أولًا.

## المراجع

- Google Android authorization: https://developer.android.com/identity/authorization
- Drive uploads: https://developers.google.com/workspace/drive/api/guides/manage-uploads
- Drive scopes: https://developers.google.com/workspace/drive/api/guides/api-specific-auth


## v485.7.131 — Google Drive via Android Documents
The backup screen uses the Android document picker (ACTION_CREATE_DOCUMENT) to save a JSON backup to a location selected by the user, including Google Drive if its provider is available. Restore uses the existing file picker and confirmation. No Google OAuth login or automatic cloud upload is required. Local scheduled backups remain unchanged. Do not uninstall or clear app data when upgrading.
