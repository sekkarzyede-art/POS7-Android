package com.sokkarzeyedeh.pos7;

import android.accounts.Account;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import com.google.android.gms.auth.api.identity.AuthorizationRequest;
import com.google.android.gms.auth.api.identity.AuthorizationResult;
import com.google.android.gms.auth.api.identity.Identity;
import com.google.android.gms.auth.api.identity.RevokeAccessRequest;
import com.google.android.gms.common.api.Scope;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Drive credentials stay native. No business-data restore or sync is performed here. */
final class DriveBackupManager {
    static final int REQUEST_AUTH = 5130;
    static final int MAX = 50 * 1024 * 1024;
    private static final String SCOPE = "https://www.googleapis.com/auth/drive.file";
    private static final String API = "https://www.googleapis.com/drive/v3/files";
    private static final String FIELDS = "id,name,size,md5Checksum,createdTime,appProperties";
    interface Listener {
        void result(boolean ok, String message, String account, String name, String json);
    }
    private final Activity activity;
    private final Listener listener;
    private final SharedPreferences prefs;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private boolean busy, closed;
    private String operation, fileName, payload;
    DriveBackupManager(Activity activity, Listener listener) {
        this.activity=activity; this.listener=listener;
        prefs=activity.getSharedPreferences("pos7_google_drive",Activity.MODE_PRIVATE);
    }
    String account() { return prefs.getString("account", ""); }
    void close() { closed=true; payload=null; worker.shutdownNow(); }
    void start(String action, String name, String json) {
        if(closed)return;
        if(busy){listener.result(false,"هناك عملية Google Drive قيد التنفيذ",account(),null,null);return;}
        if(!("connect".equals(action)||"upload".equals(action)||"download".equals(action)||"disconnect".equals(action)))return;
        busy=true;operation=action;fileName=name;payload=json;
        if("disconnect".equals(action)){disconnect();return;}
        AuthorizationRequest.Builder request=AuthorizationRequest.builder()
            .setRequestedScopes(Collections.singletonList(new Scope(SCOPE)));
        if(!account().isEmpty())request.setAccount(new Account(account(),"com.google"));
        Identity.getAuthorizationClient(activity).authorize(request.build())
            .addOnSuccessListener(this::authorized)
            .addOnFailureListener(e->finish(false,authError(e),null,null));
    }
    private String authError(Exception e) {
        int code=e instanceof com.google.android.gms.common.api.ApiException
            ?((com.google.android.gms.common.api.ApiException)e).getStatusCode():-1;
        return "تعذر ربط Google Drive ("+code+"). تحقق من الإنترنت وخدمات Google Play، ومن تفعيل Drive API وتسجيل حزمة التطبيق والتوقيع الأصلي في Google Cloud.";
    }
    private void authorized(AuthorizationResult result) {
        if(closed)return;
        try {
            if(result.hasResolution()){
                if(result.getPendingIntent()==null)throw new IOException("لم يصل طلب موافقة Google");
                activity.startIntentSenderForResult(result.getPendingIntent().getIntentSender(),REQUEST_AUTH,null,0,0,0);
                return;
            }
            final String token=result.getAccessToken();
            if(token==null||!result.getGrantedScopes().contains(SCOPE))throw new IOException("لم تُمنح صلاحية ملفات Google Drive");
            final String op=operation, name=fileName, json=payload;
            worker.execute(()->{
                try {
                    String email=object(request("GET","https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)",token,null,null).body).getJSONObject("user").getString("emailAddress");
                    if(email.isEmpty())throw new IOException("تعذر تحديد حساب Drive");
                    prefs.edit().putString("account",email).apply();
                    if("connect".equals(op)){finish(true,"تم ربط Google Drive؛ يمكنك حفظ نسخة الآن",null,null);return;}
                    if("upload".equals(op)){upload(token,name,json);finish(true,"تم حفظ النسخة والتحقق منها في Google Drive / POS7 Backups",null,null);}
                    else download(token);
                } catch(Exception e){finish(false,"تعذر إكمال العملية: "+safeError(e),null,null);}
            });
        }catch(Exception e){finish(false,safeError(e),null,null);}
    }
    boolean activityResult(int requestCode,int resultCode,Intent data){
        if(requestCode!=REQUEST_AUTH)return false;
        if(resultCode!=Activity.RESULT_OK||data==null){finish(false,"أُلغيت موافقة Google؛ لم تتغير بيانات المتجر",null,null);return true;}
        try{authorized(Identity.getAuthorizationClient(activity).getAuthorizationResultFromIntent(data));}
        catch(Exception e){finish(false,authError(e),null,null);}
        return true;
    }
    private void disconnect(){
        if(account().isEmpty()){finish(true,"لا يوجد حساب مرتبط؛ يمكنك الربط من جديد",null,null);return;}
        RevokeAccessRequest request=RevokeAccessRequest.builder()
            .setAccount(new Account(account(),"com.google"))
            .setScopes(Collections.singletonList(new Scope(SCOPE))).build();
        Identity.getAuthorizationClient(activity).revokeAccess(request)
            .addOnSuccessListener(v->{prefs.edit().remove("account").apply();finish(true,"تم فصل Google Drive؛ النسخ السابقة باقية في حسابك",null,null);})
            .addOnFailureListener(e->finish(false,authError(e),null,null));
    }
    private void finish(boolean ok,String message,String name,String json){
        activity.runOnUiThread(()->{
            busy=false;payload=null;fileName=null;
            if(!closed)listener.result(ok,message,account(),name,json);
        });
    }
    private static String safeError(Exception e){
        if(e instanceof java.net.SocketTimeoutException)return "انتهت مهلة الاتصال. قد يكون الرفع اكتمل؛ تحقق بتنزيل آخر نسخة قبل إعادة المحاولة";
        if(e instanceof java.net.UnknownHostException)return "لا يوجد اتصال بخدمة Google Drive";
        return e instanceof IOException ? e.getMessage() : "حدث خطأ؛ حاول مجددًا دون تغيير بيانات المتجر";
    }
    static void validate(byte[] bytes)throws Exception{
        if(bytes.length==0||bytes.length>MAX)throw new IOException("حجم النسخة غير صالح (الحد 50 ميغابايت)");
        JSONObject b=new JSONObject(new String(bytes,StandardCharsets.UTF_8)),d=b.optJSONObject("data");
        if(!"POS7".equals(b.optString("app"))||d==null||d.optJSONArray("products")==null||d.optJSONArray("sales")==null||d.optJSONArray("purchases")==null)
            throw new IOException("ملف النسخة غير صالح للاستعادة");
    }
    private static String hash(String algorithm,byte[] bytes)throws Exception{
        StringBuilder s=new StringBuilder();for(byte b:MessageDigest.getInstance(algorithm).digest(bytes))s.append(String.format(Locale.ROOT,"%02x",b&255));return s.toString();
    }
    private static String enc(String s)throws Exception{return URLEncoder.encode(s,"UTF-8");}
    private JSONObject list(String token,String query,String order,int count)throws Exception{
        return object(request("GET",API+"?q="+enc(query)+"&spaces=drive&pageSize="+count+"&orderBy="+enc(order)+"&fields="+enc("files("+FIELDS+")"),token,null,null).body);
    }
    private String folder(String token)throws Exception{
        JSONArray files=list(token,"trashed=false and mimeType='application/vnd.google-apps.folder' and appProperties has { key='pos7Folder' and value='tablet-backups-v1' }","createdTime",1).getJSONArray("files");
        if(files.length()>0)return files.getJSONObject(0).getString("id");
        JSONObject metadata=new JSONObject().put("name","POS7 Backups").put("mimeType","application/vnd.google-apps.folder")
            .put("appProperties",new JSONObject().put("pos7Folder","tablet-backups-v1"));
        return object(request("POST",API+"?fields=id",token,metadata.toString().getBytes(StandardCharsets.UTF_8),"application/json; charset=UTF-8").body).getString("id");
    }
    private void upload(String token,String name,String json)throws Exception{
        if(json==null||json.length()>MAX)throw new IOException("حجم النسخة غير صالح");
        byte[] bytes=json.getBytes(StandardCharsets.UTF_8);validate(bytes);
        JSONObject metadata=new JSONObject().put("name",name).put("mimeType","application/json")
            .put("parents",new JSONArray().put(folder(token)))
            .put("appProperties",new JSONObject().put("pos7Backup","tablet-v1").put("sha256",hash("SHA-256",bytes)).put("version","485.7.130"));
        Reply init=request("POST","https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields="+enc(FIELDS),token,metadata.toString().getBytes(StandardCharsets.UTF_8),"application/json; charset=UTF-8");
        if(init.location==null)throw new IOException("لم تصل جلسة الرفع من Drive");
        URL url=new URL(init.location);
        if(!"https".equals(url.getProtocol())||!"www.googleapis.com".equals(url.getHost()))throw new IOException("عنوان رفع غير صالح");
        JSONObject saved=object(request("PUT",init.location,token,bytes,"application/json").body);
        if(saved.optString("id").isEmpty()||saved.optLong("size",-1)!=bytes.length||!hash("MD5",bytes).equals(saved.optString("md5Checksum")))
            throw new IOException("لم يكتمل التحقق من النسخة؛ تحقق بتنزيل آخر نسخة قبل إعادة الرفع");
    }
    private void download(String token)throws Exception{
        JSONArray files=list(token,"trashed=false and mimeType='application/json' and appProperties has { key='pos7Backup' and value='tablet-v1' }","createdTime desc",1).getJSONArray("files");
        if(files.length()==0)throw new IOException("لا توجد نسخة أنشأها هذا التطبيق في حساب Google المحدد");
        JSONObject file=files.getJSONObject(0);
        long size=file.optLong("size",-1);if(size<=0||size>MAX)throw new IOException("حجم النسخة غير صالح؛ لم تتغير بيانات الجهاز");
        byte[] bytes=request("GET",API+"/"+enc(file.getString("id"))+"?alt=media",token,null,null).body;
        validate(bytes);
        JSONObject props=file.optJSONObject("appProperties");
        if(bytes.length!=size||!hash("MD5",bytes).equals(file.optString("md5Checksum"))||props==null||!hash("SHA-256",bytes).equals(props.optString("sha256")))
            throw new IOException("لم تجتز النسخة فحص السلامة؛ لم تتغير بيانات الجهاز");
        finish(true,"تم تنزيل آخر نسخة والتحقق منها؛ جارٍ حفظ الملف. استخدم «استعادة نسخة» بعد الحفظ.",file.getString("name"),new String(bytes,StandardCharsets.UTF_8));
    }
    private static JSONObject object(byte[] b)throws Exception{return new JSONObject(new String(b,StandardCharsets.UTF_8));}
    private static class Reply{byte[] body;String location;}
    private Reply request(String method,String url,String token,byte[] data,String type)throws Exception{
        HttpURLConnection connection=(HttpURLConnection)new URL(url).openConnection();
        connection.setConnectTimeout(20000);connection.setReadTimeout(60000);connection.setInstanceFollowRedirects(false);
        connection.setRequestMethod(method);connection.setRequestProperty("Authorization","Bearer "+token);
        try{
            if(data!=null){connection.setDoOutput(true);connection.setRequestProperty("Content-Type",type);connection.setFixedLengthStreamingMode(data.length);
                try(OutputStream out=connection.getOutputStream()){out.write(data);}}
            int code=connection.getResponseCode();
            if(code<200||code>=300){
                if(code==401)throw new IOException("انتهت صلاحية اتصال Google؛ أعد المحاولة أو افصل الحساب واربطه مجددًا");
                if(code==403)throw new IOException("رفض Drive الطلب؛ تحقق من تفعيل Drive API وصلاحية الحساب والمساحة المتاحة");
                throw new IOException("تعذر الاتصال بـ Drive (HTTP "+code+")؛ لم تتغير بيانات الجهاز");
            }
            Reply reply=new Reply();reply.location=connection.getHeaderField("Location");
            try(InputStream in=connection.getInputStream();ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] block=new byte[16384];int n;
                while((n=in.read(block))!=-1){if(Thread.currentThread().isInterrupted())throw new IOException("توقفت العملية");if(out.size()+n>MAX)throw new IOException("الملف أكبر من الحد المسموح");out.write(block,0,n);}
                reply.body=out.toByteArray();
            }return reply;
        }finally{connection.disconnect();}
    }
}
