package com.sokkarzeyedeh.pos7;
public class BackupFileProvider extends androidx.core.content.FileProvider {}
