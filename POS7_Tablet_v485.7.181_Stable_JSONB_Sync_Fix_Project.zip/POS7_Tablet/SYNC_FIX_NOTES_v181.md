# POS7 Tablet 485.7.181 — JSONB stable-comparison repair

Based on 485.7.180, with all existing business/accounting screens retained.

## Change
- Canonical deep, sorted-key JSON comparison for table rows, including nested objects, while retaining array order.
- Exclude volatile `meta.generatedAt` as in 485.7.180.
- Apply the same comparator to both bulk reconciliation and critical receipt patches.
- Diagnostics now display change counts by the largest 8 table groups.
- Preserve existing receipt idempotency, original application ID, and signing-certificate check.
- Test: simulate PostgreSQL JSONB round trip, compare before and after app-start cloud refresh, verify zero spurious diffs.
- Test: one genuinely changed record updates; different array order is a real change.

## Limits and safety
- This corrects falsely detected differences caused by JSON key reordering; other causes of actual data changes or cloud latency may still exist.
- HTML preview is read-only. Do not move production ledger into Chrome.
- No production Supabase connection or actual tablet ledger was available for live tests.
- First make an external backup of the original tablet. Do not uninstall or clear data.
- Pending $40+$100+$306 customer receipts require a one-by-one ledger reconciliation before considering them processed.
- GitHub Actions must sign with the existing four keystore secrets. No signing credentials are inside this archive.
