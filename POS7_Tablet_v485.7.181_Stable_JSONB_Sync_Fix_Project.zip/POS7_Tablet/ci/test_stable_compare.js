const fs=require('fs'),vm=require('vm'),assert=require('assert');
const text=fs.readFileSync(require('path').resolve(__dirname,'../app/src/main/assets/index.html'),'utf8');
const start=text.indexOf('function syncComparable('),end=text.indexOf('function patchSize(',start);
assert(start>0&&end>start);const snippet=text.slice(start,end);
const ctx={console,baseline:{},setTimeout};vm.createContext(ctx);vm.runInContext(snippet,ctx);
const row={id:'p1',name:'test',stock:12,details:{b:2,a:1},items:[{ref:'B',qty:2},{ref:'A',qty:3}]};
// Simulate a PostgreSQL JSONB response with reordered keys, including nested keys.
const jsonb={items:[{qty:2,ref:'B'},{qty:3,ref:'A'}],details:{a:1,b:2},stock:12,name:'test',id:'p1'};
assert.strictEqual(ctx.pos181Fingerprint('products',row),ctx.pos181Fingerprint('products',jsonb));
const r=ctx.delta({products:{p1:row}},{products:{p1:jsonb}},()=>true);
r.then(p=>{assert.deepEqual(Object.keys(p),[]);console.log('PASS JSONB reordered keys => zero patch');}).catch(e=>{throw e});
assert.notStrictEqual(ctx.pos181Fingerprint('products',row),ctx.pos181Fingerprint('products',{...jsonb,stock:13}));
assert.notStrictEqual(ctx.pos181Fingerprint('products',row),ctx.pos181Fingerprint('products',{...jsonb,items:[...jsonb.items].reverse()}));
console.log('PASS real field changes and array order are detected');
const m1={generatedAt:'2026-10-31',store:'pos7',schema:1,fxRate:90000};
const m2={fxRate:90000,schema:1,generatedAt:'2026-11-01',store:'pos7'};
assert.strictEqual(ctx.pos181Fingerprint('meta',m1),ctx.pos181Fingerprint('meta',m2));
console.log('PASS meta timestamp ignored');
(async()=>{
 const next={products:{p1:row},receipts:{r1:{amountUSD:40,ref:'OP-event-1'}}};
 let old={receipts:{r1:{ref:'OP-event-1',amountUSD:40}},products:{p1:jsonb}};
 for(let i=0;i<3;i++){
  const delta=await ctx.delta(next,old,()=>true);
  assert.equal(Object.keys(delta).length,0,'unexpected re-upload after restart '+i);
  // each new iteration represents a complete cloud snapshot reload and object reconstruction
  old=JSON.parse(JSON.stringify(old));
 }
 const changed={products:{p1:{...row,stock:13}},receipts:next.receipts};
 const actual=await ctx.delta(changed,old,()=>true);
 assert.deepEqual(Object.keys(actual),['products']);
 assert.deepEqual(Object.keys(actual.products.upsert),['p1']);
 console.log('PASS 3 simulated restarts no retransmit; 1 real edit produces 1 update');
})().catch(e=>{console.error(e);process.exitCode=1});
