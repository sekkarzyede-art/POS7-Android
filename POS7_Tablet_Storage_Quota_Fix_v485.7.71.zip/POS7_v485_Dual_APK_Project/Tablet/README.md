# POS7 Tablet storage quota update

This archive contains the tablet Android project only. The owner-phone project and its APK are not included or modified. Keep the existing owner-phone APK and cloud configuration.
