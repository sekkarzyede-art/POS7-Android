# POS7 Tablet v485.7.71 — local storage quota fix

Tablet-only update. Application ID remains `com.sokkarzeyedeh.pos7`; version code is `4850771`; version name is `485.7.71`. It is configured for update-in-place and must be signed with the existing POS7 release keystore.

The tablet's localStorage JSON values are transparently DEFLATE-compressed with a versioned prefix. Existing large JSON entries are migrated losslessly on startup. No business records, audit entries, WhatsApp queue items, Supabase rows, credentials, or phone-app files are intentionally deleted or rewritten semantically. The cloud sync code and Supabase configuration are unchanged.

Build from the tablet project using the supplied GitHub Actions workflow. The workflow checks the package ID, version, signature, and expected existing SHA-256 signing certificate before uploading the APK artifact.
