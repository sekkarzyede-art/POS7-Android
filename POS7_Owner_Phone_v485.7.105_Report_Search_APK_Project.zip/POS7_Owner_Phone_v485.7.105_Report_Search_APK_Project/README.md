# POS7 Owner Phone v485.7.105 — push notification APK source

This source keeps the installed owner-phone Android identity (`com.sokkarzeyedeh.pos7owner`) and existing POS7 release certificate. It uses the v485.7.105 owner-phone HTML as its UI and adds native Firebase Cloud Messaging reception for Android lock-screen notifications. Version name is `485.7.105`, version code `48507105`.

## Required one-time setup

1. In Firebase, register an Android app with the exact package `com.sokkarzeyedeh.pos7owner`, enable Firebase Cloud Messaging, and download its `google-services.json`. Convert the file to base64 and save it in GitHub Actions as secret `POS7_FIREBASE_JSON_BASE64`. The APK workflow validates the package before building.
2. Keep the existing signing secrets unchanged: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The workflow verifies the original POS7 certificate fingerprint and refuses a mismatched build.
3. Apply `supabase/migrations/202610190001_pos7_push_notifications.sql` to the existing POS7 Supabase project. This creates an owner-device token table and an outbox trigger on changes to the existing `pos7_owner_snapshot`; it does not edit sales, balances, or other accounting rows.
4. Deploy `supabase/functions/pos7-push` with Supabase CLI and `--no-verify-jwt`. Set Edge Function secrets `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `FCM_SERVICE_ACCOUNT_JSON` (Firebase service-account JSON), and `POS7_PUSH_WEBHOOK_SECRET`. Keep service-role and Firebase private-key values out of GitHub source and the APK.
5. In Supabase Dashboard, create a Database Webhook for `public.pos7_push_events`, event `INSERT`, pointing to `https://<project-ref>.supabase.co/functions/v1/pos7-push`. Add header `x-pos7-webhook-secret` with the same secret configured above.
6. Add the project ZIP to the POS7 repository root and this workflow as `.github/workflows/main.yml`; keep `POS7_FIREBASE_JSON_BASE64` and the original signing secrets in GitHub Actions. Run the workflow and download the APK artifact.

Notifications are sent after the tablet publishes a successful data change to the existing cloud snapshot. Delivery therefore follows the tablet's cloud-sync interval and requires network access on both devices. Android 13+ asks the user to permit notifications. Tapping the notification opens POS7.

## Security and data behavior

The phone registers its FCM token only after owner login and removes the registration on logout. Only device tokens are stored in `pos7_owner_push_tokens`; the FCM service-account private key stays in Supabase Edge Function secrets. The push outbox contains concise change metadata, not item lists or the full accounting database. No production Supabase migration or Firebase project has been applied by packaging this source.

