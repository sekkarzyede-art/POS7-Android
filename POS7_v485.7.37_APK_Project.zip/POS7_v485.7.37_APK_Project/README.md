# POS7 v485.7.37 — Android APK project

This Android WebView project embeds the v485.7.37 POS7 application in `app/src/main/assets/index.html`. The package name remains `com.sokkarzeyedeh.pos7` so the release can update the installed POS7 app and retain its data, provided you sign it with the same keystore.

## Build with GitHub Actions

1. Upload `POS7_v485.7.37_APK_Project.zip` to the root of the POS7 repository, or upload the extracted `POS7_v485.7.37_APK_Project` folder.
2. Copy the supplied `main.yml` to `.github/workflows/main.yml` in that repository.
3. Confirm the repository Actions secrets exist: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. Use the same release keystore used to sign the installed app.
4. Open **Actions**, run **Build POS7 v485.7.37 APK**, then download artifact `POS7-v485.7.37-release-update-apk`.

The project uses application ID `com.sokkarzeyedeh.pos7`, version code `4850737`, and version name `485.7.37`.
