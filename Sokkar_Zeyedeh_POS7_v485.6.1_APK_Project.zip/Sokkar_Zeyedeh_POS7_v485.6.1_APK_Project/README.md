# متجر سكر زيادة — مشروع APK v485.6.1

يحتوي هذا المشروع على واجهة POS7 الأحدث داخل تطبيق Android WebView وعلى ملف HTML مستقل للتجربة في Chrome.

- اسم التطبيق: متجر سكر زيادة
- رقم الإصدار: 485.6.1
- `versionCode`: 486 لتثبيت التحديث فوق إصدار 485
- `applicationId`: `com.sokkarzeyedeh.pos7` (محفوظ للتحديث فوق التطبيق الحالي)
- ملفات الواجهة: `app/src/main/assets/index.html` و`Sokkar_Zeyedeh_POS7_v485.6.1_Chrome_Test.html`

## البناء من GitHub Actions

1. ارفع `Sokkar_Zeyedeh_POS7_v485.6.1_APK_Project.zip` إلى جذر مستودع GitHub على فرع `main`.
2. أنشئ الملف `.github/workflows/main.yml` والصق محتوى ملف `main.yml` المرفق.
3. أضف أسرار التوقيع الأربعة في إعدادات المستودع: `POS7_KEYSTORE_BASE64` و`POS7_KEYSTORE_PASSWORD` و`POS7_KEY_ALIAS` و`POS7_KEY_PASSWORD`.
4. من تبويب **Actions** شغّل **Build POS7 v485.6.1 APK**.
5. نزّل ملف APK من Artifact باسم `Sokkar-Zeyedeh-POS7-v485.6.1-release-update-apk`.

يجب استخدام ملف التوقيع نفسه الذي وقّع نسخة التطبيق المثبتة لتتمكن من تثبيت APK كتحديث. لم يُبنَ APK داخل هذه الحزمة؛ هذه ملفات المشروع وملف سير البناء.
