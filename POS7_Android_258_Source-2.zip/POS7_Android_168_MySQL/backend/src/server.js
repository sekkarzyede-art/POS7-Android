import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import mysql from 'mysql2/promise';

const app = express();
app.use(helmet());
app.use(cors());
app.use(express.json({limit:'10mb'}));
const pool = mysql.createPool({host:process.env.MYSQL_HOST,port:Number(process.env.MYSQL_PORT||3306),user:process.env.MYSQL_USER,password:process.env.MYSQL_PASSWORD,database:process.env.MYSQL_DATABASE,waitForConnections:true,connectionLimit:10,decimalNumbers:true});

app.use('/api',(req,res,next)=>{
  if(req.path==='/health') return next();
  if(!process.env.API_KEY || req.get('x-api-key')!==process.env.API_KEY) return res.status(401).json({ok:false,error:'unauthorized'});
  next();
});
app.get('/api/health',async(req,res)=>{try{await pool.query('SELECT 1');res.json({ok:true,db:'mysql'});}catch(e){res.status(503).json({ok:false,error:'db_unavailable'});}});
app.post('/api/sync/snapshot',async(req,res)=>{
  const device=String(req.body.device_id||'android'); const payload=req.body.state;
  if(!payload||typeof payload!=='object') return res.status(400).json({ok:false,error:'state_required'});
  await pool.execute('INSERT INTO sync_snapshots(device_id,payload_json) VALUES (?,?)',[device,JSON.stringify(payload)]);
  res.json({ok:true});
});
app.get('/api/sync/latest/:device',async(req,res)=>{
  const [rows]=await pool.execute('SELECT id,payload_json,created_at FROM sync_snapshots WHERE device_id=? ORDER BY id DESC LIMIT 1',[req.params.device]);
  if(!rows.length)return res.status(404).json({ok:false});
  res.json({ok:true,id:rows[0].id,state:typeof rows[0].payload_json==='string'?JSON.parse(rows[0].payload_json):rows[0].payload_json,created_at:rows[0].created_at});
});
app.listen(Number(process.env.PORT||8080),()=>console.log('POS7 API ready'));
