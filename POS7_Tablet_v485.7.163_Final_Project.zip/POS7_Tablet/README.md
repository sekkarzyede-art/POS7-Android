# POS7 Tablet 485.7.163

Upload POS7_Tablet_v485.7.163_Final_Project.zip to repository root of sekkarzyede-art/POS7-Android. Copy main.yml to .github/workflows/main.yml.
Existing original four signing secrets are required. No key material is included in this archive.
APK is produced only after successful GitHub Actions build and certificate verification.
Package com.sokkarzeyedeh.pos7; same WebView origin and storage. Do not uninstall the existing app.
VersionName and caption 485.7.163. Minimum code 48507630; supply actual installed_version_code if higher.
Customer opportunities load and calculate 15 customers per batch; full-name search and last-four invoice viewer retained.
Independent backups: select a persistent external folder, then save manually. Verify new file before keeping latest20 valid POS7_Independent files. Other files and cloud backups are not deleted. WhatsApp opens Android sharing.
Existing internal backup schedule is unchanged. This release does not add automatic external scheduling.
Live Drive/Firebase, Bluetooth, Android installation and external-folder retention need device testing.
