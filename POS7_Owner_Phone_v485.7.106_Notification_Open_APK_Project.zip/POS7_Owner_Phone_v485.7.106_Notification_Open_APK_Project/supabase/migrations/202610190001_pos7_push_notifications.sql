begin;

create table if not exists public.pos7_owner_push_tokens (
  store_id text not null default 'pos7' check (store_id = 'pos7'),
  owner_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  fcm_token text not null unique,
  platform text not null default 'android',
  updated_at timestamptz not null default now(),
  primary key (owner_id, device_id)
);

alter table public.pos7_owner_push_tokens enable row level security;
drop policy if exists pos7_owner_push_tokens_select on public.pos7_owner_push_tokens;
drop policy if exists pos7_owner_push_tokens_insert on public.pos7_owner_push_tokens;
drop policy if exists pos7_owner_push_tokens_update on public.pos7_owner_push_tokens;
drop policy if exists pos7_owner_push_tokens_delete on public.pos7_owner_push_tokens;
create policy pos7_owner_push_tokens_select on public.pos7_owner_push_tokens
  for select to authenticated using (owner_id = auth.uid() and public.pos7_is_member(store_id, array['owner']));
create policy pos7_owner_push_tokens_insert on public.pos7_owner_push_tokens
  for insert to authenticated with check (owner_id = auth.uid() and public.pos7_is_member(store_id, array['owner']));
create policy pos7_owner_push_tokens_update on public.pos7_owner_push_tokens
  for update to authenticated using (owner_id = auth.uid() and public.pos7_is_member(store_id, array['owner']))
  with check (owner_id = auth.uid() and public.pos7_is_member(store_id, array['owner']));
create policy pos7_owner_push_tokens_delete on public.pos7_owner_push_tokens
  for delete to authenticated using (owner_id = auth.uid() and public.pos7_is_member(store_id, array['owner']));
revoke all on public.pos7_owner_push_tokens from anon, public;
grant select, insert, update, delete on public.pos7_owner_push_tokens to authenticated;

create table if not exists public.pos7_push_events (
  id bigint generated always as identity primary key,
  store_id text not null default 'pos7' check (store_id = 'pos7'),
  event_key text not null unique,
  payload jsonb not null,
  created_at timestamptz not null default now(),
  processing_at timestamptz,
  delivered_at timestamptz
);
alter table public.pos7_push_events enable row level security;
revoke all on public.pos7_push_events from anon, authenticated, public;

create or replace function public.pos7_owner_snapshot_push_outbox()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  section_name text;
  record_id text;
  old_doc jsonb;
  new_doc jsonb;
  op text;
  ref text;
  party text;
  amount text;
  currency text;
  label text;
  body jsonb;
begin
  if tg_op <> 'UPDATE' then return new; end if;
  -- Do not turn the first cloud snapshot into hundreds of historical alerts.
  if coalesce(old.revision, 0) = 0 and coalesce(old.sections, '{}'::jsonb) = '{}'::jsonb then return new; end if;
  for section_name in
    select unnest(array['sales','purchases','receipts','payments','expenses','returns','walletTx','cashLedger'])
  loop
    if (old.sections -> section_name) is not distinct from (new.sections -> section_name) then continue; end if;
    for record_id in
      select key from jsonb_each(coalesce(old.sections -> section_name, '{}'::jsonb))
      union
      select key from jsonb_each(coalesce(new.sections -> section_name, '{}'::jsonb))
    loop
      old_doc := old.sections -> section_name -> record_id;
      new_doc := new.sections -> section_name -> record_id;
      if old_doc is not distinct from new_doc then continue; end if;
      op := case when old_doc is null then 'created' when new_doc is null then 'deleted' else 'updated' end;
      body := coalesce(new_doc, old_doc);
      ref := coalesce(body ->> 'number', body ->> 'ref', body ->> 'invoiceNumber', record_id);
      party := coalesce(body ->> 'customer', body ->> 'supplier', body ->> 'party', body ->> 'name', body ->> 'account', '');
      amount := coalesce(body ->> 'totalUSD', body ->> 'amountUSD', body ->> 'total', body ->> 'amount', body ->> 'value', '');
      currency := coalesce(body ->> 'currency', 'USD');
      label := case section_name
        when 'sales' then 'فاتورة بيع'
        when 'purchases' then 'فاتورة شراء'
        when 'receipts' then 'سند قبض'
        when 'payments' then 'سند صرف'
        when 'expenses' then 'مصروف'
        when 'returns' then 'مرتجع'
        when 'walletTx' then 'حركة محفظة'
        else 'حركة صندوق'
      end;
      insert into public.pos7_push_events(store_id, event_key, payload)
      values (
        new.store_id,
        new.revision::text || ':' || section_name || ':' || record_id || ':' || op,
        jsonb_build_object(
          'store_id', new.store_id,
          'revision', new.revision,
          'section', section_name,
          'operation', op,
          'label', label,
          'reference', ref,
          'party', party,
          'amount', amount,
          'currency', currency,
          'old_amount', coalesce(old_doc ->> 'totalUSD', old_doc ->> 'amountUSD', old_doc ->> 'total', old_doc ->> 'amount', ''),
          'new_amount', coalesce(new_doc ->> 'totalUSD', new_doc ->> 'amountUSD', new_doc ->> 'total', new_doc ->> 'amount', '')
        )
      ) on conflict (event_key) do nothing;
    end loop;
  end loop;
  return new;
end;
$$;

drop trigger if exists pos7_owner_snapshot_push_outbox on public.pos7_owner_snapshot;
create trigger pos7_owner_snapshot_push_outbox
  after update of sections on public.pos7_owner_snapshot
  for each row execute function public.pos7_owner_snapshot_push_outbox();

commit;
