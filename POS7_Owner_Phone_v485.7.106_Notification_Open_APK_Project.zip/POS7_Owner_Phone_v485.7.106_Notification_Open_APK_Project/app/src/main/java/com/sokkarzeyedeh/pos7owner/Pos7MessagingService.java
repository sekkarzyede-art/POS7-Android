package com.sokkarzeyedeh.pos7owner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public final class Pos7MessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token) {
        getSharedPreferences(MainActivity.PUSH_PREFS, MODE_PRIVATE).edit().putString("fcm_token", token).apply();
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        String title = message.getNotification() != null ? message.getNotification().getTitle() : null;
        String body = message.getNotification() != null ? message.getNotification().getBody() : null;
        Map<String, String> data = message.getData();
        if (title == null || title.trim().isEmpty()) title = data.getOrDefault("title", "حركة جديدة في متجر سكر زيادة");
        if (body == null || body.trim().isEmpty()) body = data.getOrDefault("body", "تم تسجيل تغيير جديد في بيانات المتجر.");
        showNotification(title, body, data);
    }

    private void showNotification(String title, String body, Map<String, String> data) {
        String eventId = data.get("event_id");
        Context context = getApplicationContext();
        NotificationManager manager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(MainActivity.PUSH_CHANNEL) == null) {
            manager.createNotificationChannel(new NotificationChannel(MainActivity.PUSH_CHANNEL, "حركات المتجر", NotificationManager.IMPORTANCE_DEFAULT));
        }
        Intent open = new Intent(context, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        if (eventId != null) open.putExtra("pos7_event_id", eventId);
        for (String key : new String[]{"section", "record_id", "reference", "operation", "party", "amount", "currency"}) {
            String value = data.get(key);
            if (value != null) open.putExtra("pos7_" + key, value);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(context, eventId == null ? 0 : eventId.hashCode(), open, flags);
        Notification notification = new NotificationCompat.Builder(context, MainActivity.PUSH_CHANNEL)
                .setSmallIcon(com.sokkarzeyedeh.pos7owner.R.drawable.ic_stat_pos7)
                .setColor(0xFF0F8B61)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build();
        manager.notify(eventId == null ? (int) System.currentTimeMillis() : eventId.hashCode(), notification);
    }
}
