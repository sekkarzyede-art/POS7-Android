# POS7 v489 — إصلاح الرجوع إلى التطبيق

هذا المشروع مبني على v484 ويضم واجهة POS7 v488. عولج فتح التطبيق كنسخة نشاط ثانية عند العودة من أيقونته: أصبح نشاط Android وحيداً (`singleTask`) وتبقى حالة المهمة، كما لا يعاد تحميل WebView عند وصول Intent جديد. يحتفظ WebView بحالته عبر `onSaveInstanceState`، وتحفظ الواجهة المستخدم والصفحة الحالية محلياً.

## التحديث وحفظ البيانات

- معرّف التطبيق ثابت: `com.sokkarzeyedeh.pos7`.
- رُفع `versionCode` إلى 489 حتى يقبل كتحديث فوق 484.
- لا يمسح المشروع بيانات التطبيق عند التشغيل.
- يجب استعمال مفتاح التوقيع نفسه الذي وقّع APK المثبت حتى يقبل Android التحديث مع بقاء البيانات.

## البناء

1. ارفع `POS7_v489_APK_Project.zip` إلى جذر المستودع.
2. انسخ `POS7_v489_main.yml` إلى `.github/workflows/main.yml`.
3. شغّل **Build POS7 v489 signed update APK** من Actions.
4. نزّل artifact باسم `POS7-v489-release-update-apk`.

يتطلب البناء أسرار GitHub الأربعة التي استخدمتها للنسخة السابقة: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`.
