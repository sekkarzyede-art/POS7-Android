# POS7 Tablet APK Project v485.7.104

- Application ID remains `com.sokkarzeyedeh.pos7` so Android treats this as an in-place update.
- Version code: `48507104`; version name: `485.7.104`.
- Performance work: avoid recalculating the home dashboard on unrelated page navigation; reuse indexed product/name and barcode-prefix searches in purchase lookup; shorten inventory search debounce; remove the per-keystroke sale search beep while keeping the add-item beep.
- The changes modify UI/search behavior only. They keep the existing local-storage key and compression format; they do not clear or migrate store records.
- Uses the same tablet signing certificate guard as prior POS7 builds. Owner phone app is unchanged.

Build with the same tablet release keystore as the installed app. Configure GitHub Actions secrets `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The workflow verifies certificate SHA-256 `843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495` before and after building, to prevent an incompatible update.
