package com.sokkarzeyedeh.pos7;

import android.app.Activity;
import android.app.AlertDialog;
import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.SharedPreferences;
import android.util.Base64;
import java.io.OutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.UUID;

public final class MainActivity extends Activity {
    private WebView webView;
    private final ArrayList<WebView> printWebViews = new ArrayList<>();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 4510;
    private static final int BLUETOOTH_PERMISSION_REQUEST = 4711;
    private static final int BLUETOOTH_ENABLE_REQUEST = 4712;
    private static final String PREFS = "pos7_printer";
    private static final String PREF_ADDRESS = "bluetooth_address";
    private static final String PREF_NAME = "bluetooth_name";
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private Runnable pendingBluetoothAction;
    private boolean pickAfterBluetoothEnable;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidPrintBridge(this), "Pos7Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                notifyJsPrinterSelected();
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private final class AndroidPrintBridge {
        private final Context context;
        AndroidPrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printHtml(String html, String jobName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(context, "محتوى الطباعة فارغ", Toast.LENGTH_SHORT).show());
                return;
            }
            runOnUiThread(() -> openSystemPrint(html, jobName));
        }

        @JavascriptInterface public void chooseBluetoothPrinter() {
            runOnUiThread(() -> withBluetoothPermission(() -> showBondedPrinterPicker(false)));
        }

        @JavascriptInterface public String getSelectedBluetoothPrinterName() {
            return getPrinterPrefs().getString(PREF_NAME, "");
        }

        @JavascriptInterface public String getSelectedBluetoothPrinterAddress() {
            return getPrinterPrefs().getString(PREF_ADDRESS, "");
        }

        @JavascriptInterface public void printBluetoothBase64(String encoded, String jobName) {
            if (encoded == null || encoded.isEmpty()) {
                notifyJsPrintResult(false, "بيانات الطباعة فارغة");
                return;
            }
            final byte[] bytes;
            try { bytes = Base64.decode(encoded, Base64.DEFAULT); }
            catch (IllegalArgumentException e) {
                notifyJsPrintResult(false, "تعذر تجهيز بيانات الطباعة");
                return;
            }
            String address = getPrinterPrefs().getString(PREF_ADDRESS, "");
            if (address.isEmpty()) {
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this, "اختر الطابعة المقترنة أولاً", Toast.LENGTH_LONG).show();
                    withBluetoothPermission(() -> showBondedPrinterPicker(false));
                });
                return;
            }
            runOnUiThread(() -> withBluetoothPermission(() -> sendToBluetoothPrinter(address, bytes, jobName)));
        }
    }

    private SharedPreferences getPrinterPrefs() {
        return getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private void withBluetoothPermission(Runnable action) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            pendingBluetoothAction = action;
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT}, BLUETOOTH_PERMISSION_REQUEST);
            return;
        }
        action.run();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == BLUETOOTH_PERMISSION_REQUEST) {
            Runnable action = pendingBluetoothAction;
            pendingBluetoothAction = null;
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                if (action != null) action.run();
            } else {
                Toast.makeText(this, "اسمح للتطبيق بالوصول إلى Bluetooth لاختيار الطابعة", Toast.LENGTH_LONG).show();
                notifyJsPrinterResult("permission", "يلزم السماح بالوصول إلى Bluetooth");
            }
        }
    }

    private void showBondedPrinterPicker(boolean afterEnable) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) {
            Toast.makeText(this, "هذا الجهاز لا يدعم Bluetooth", Toast.LENGTH_LONG).show();
            notifyJsPrinterResult("unavailable", "الجهاز لا يدعم Bluetooth");
            return;
        }
        if (!adapter.isEnabled()) {
            pickAfterBluetoothEnable = true;
            try { startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), BLUETOOTH_ENABLE_REQUEST); }
            catch (Exception e) {
                Toast.makeText(this, "فعّل Bluetooth من إعدادات الهاتف ثم أعد اختيار الطابعة", Toast.LENGTH_LONG).show();
                notifyJsPrinterResult("disabled", "فعّل Bluetooth ثم أعد المحاولة");
            }
            return;
        }
        try {
            ArrayList<BluetoothDevice> devices = new ArrayList<>(adapter.getBondedDevices());
            Collections.sort(devices, Comparator.comparing((BluetoothDevice d) -> safeDeviceName(d).toLowerCase()));
            if (devices.isEmpty()) {
                new AlertDialog.Builder(this)
                    .setTitle("لا توجد طابعة مقترنة")
                    .setMessage("اقرن الطابعة مرة واحدة من إعدادات Bluetooth في الهاتف، ثم ارجع واخترها هنا.")
                    .setPositiveButton("فتح إعدادات Bluetooth", (dialog, which) -> {
                        try { startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); }
                        catch (Exception ignored) { }
                    })
                    .setNegativeButton("إغلاق", null)
                    .show();
                notifyJsPrinterResult("empty", "لا توجد طابعة مقترنة؛ افتح إعدادات Bluetooth لاقترانها");
                return;
            }
            String[] labels = new String[devices.size()];
            for (int i = 0; i < devices.size(); i++) labels[i] = safeDeviceName(devices.get(i)) + "  •  " + devices.get(i).getAddress();
            new AlertDialog.Builder(this)
                .setTitle("اختر الطابعة المقترنة")
                .setItems(labels, (dialog, which) -> saveSelectedPrinter(devices.get(which)))
                .setNeutralButton("اقتران طابعة جديدة", (dialog, which) -> {
                    try { startActivity(new Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)); }
                    catch (Exception ignored) { }
                })
                .setNegativeButton("إلغاء", null)
                .show();
        } catch (SecurityException e) {
            Toast.makeText(this, "تعذر عرض الطابعات؛ تحقق من إذن Bluetooth", Toast.LENGTH_LONG).show();
            notifyJsPrinterResult("permission", "تعذر عرض الطابعات المقترنة");
        }
    }

    private String safeDeviceName(BluetoothDevice device) {
        try {
            String name = device.getName();
            return (name == null || name.trim().isEmpty()) ? "طابعة Bluetooth" : name.trim();
        } catch (SecurityException e) { return "طابعة Bluetooth"; }
    }

    private void saveSelectedPrinter(BluetoothDevice device) {
        String name = safeDeviceName(device), address = device.getAddress();
        getPrinterPrefs().edit().putString(PREF_NAME, name).putString(PREF_ADDRESS, address).apply();
        Toast.makeText(this, "تم اختيار " + name, Toast.LENGTH_SHORT).show();
        notifyJsPrinterSelected();
    }

    private void sendToBluetoothPrinter(String address, byte[] bytes, String jobName) {
        new Thread(() -> {
            BluetoothSocket socket = null;
            try {
                BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
                if (adapter == null) throw new IOException("Bluetooth غير متاح");
                BluetoothDevice device = adapter.getRemoteDevice(address);
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
                socket.connect();
                OutputStream output = socket.getOutputStream();
                int offset = 0;
                while (offset < bytes.length) {
                    int count = Math.min(2048, bytes.length - offset);
                    output.write(bytes, offset, count);
                    offset += count;
                }
                output.flush();
                try { Thread.sleep(250); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
                notifyJsPrintResult(true, "أُرسلت الطباعة إلى " + getPrinterPrefs().getString(PREF_NAME, "الطابعة"));
            } catch (Exception e) {
                String message = e.getMessage() == null ? "تعذر الاتصال بالطابعة" : e.getMessage();
                notifyJsPrintResult(false, "فشل الاتصال بالطابعة: " + message);
            } finally {
                if (socket != null) try { socket.close(); } catch (IOException ignored) { }
            }
        }, "POS7-Bluetooth-Printer").start();
    }

    private void notifyJsPrinterSelected() {
        if (webView == null) return;
        String name = getPrinterPrefs().getString(PREF_NAME, "");
        String address = getPrinterPrefs().getString(PREF_ADDRESS, "");
        String js = "if(window.pos7OnBluetoothPrinterSelected)window.pos7OnBluetoothPrinterSelected(" +
                org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(address) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyJsPrinterResult(String code, String message) {
        if (webView == null) return;
        String js = "if(window.pos7OnBluetoothPrinterResult)window.pos7OnBluetoothPrinterResult(" +
                org.json.JSONObject.quote(code) + "," + org.json.JSONObject.quote(message) + ");";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void notifyJsPrintResult(boolean success, String message) {
        runOnUiThread(() -> {
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            if (webView != null) {
                String js = "if(window.pos7BluetoothPrintResult)window.pos7BluetoothPrintResult(" + success + "," +
                        org.json.JSONObject.quote(message) + ");";
                webView.evaluateJavascript(js, null);
            }
        });
    }

    private void openSystemPrint(String html, String jobName) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
        WebView printView = new WebView(this);
        printWebViews.add(printView);
        printView.getSettings().setJavaScriptEnabled(true);
        printView.setWebViewClient(new WebViewClient() {
            private boolean started;
            @Override public void onPageFinished(WebView view, String url) {
                if (started) return;
                started = true;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager == null) {
                    Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة على هذا الجهاز", Toast.LENGTH_LONG).show();
                    return;
                }
                String title = (jobName == null || jobName.trim().isEmpty()) ? "POS7" : jobName.trim();
                PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(new PrintAttributes.MediaSize("POS7_80MM", "80 mm thermal", 3150, 11000))
                    .setResolution(new PrintAttributes.Resolution("POS7_203DPI", "203 dpi", 203, 203))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                    .build();
                manager.print(title, view.createPrintDocumentAdapter(title), attributes);
            }
        });
        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
        if (requestCode == BLUETOOTH_ENABLE_REQUEST) {
            boolean retry = pickAfterBluetoothEnable && resultCode == RESULT_OK;
            pickAfterBluetoothEnable = false;
            if (retry) withBluetoothPermission(() -> showBondedPrinterPicker(true));
            else notifyJsPrinterResult("disabled", "لم يتم تفعيل Bluetooth");
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        for (WebView printView : printWebViews) { printView.stopLoading(); printView.destroy(); }
        printWebViews.clear();
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
