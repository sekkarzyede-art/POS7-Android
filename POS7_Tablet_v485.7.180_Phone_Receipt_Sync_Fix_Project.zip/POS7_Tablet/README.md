# POS7 Tablet v485.7.178

Upload POS7_Tablet_v485.7.178_Sales_Controls_Sync_Project.zip to the original POS7-Android repository root. Paste main.yml into .github/workflows/main.yml. Run Actions; enter actual installed versionCode if greater than the default. Download signed APK from workflow artifacts.

Required ORIGINAL repository secrets: POS7_KEYSTORE_BASE64, POS7_KEYSTORE_PASSWORD, POS7_KEY_ALIAS, POS7_KEY_PASSWORD. No replacement key. Do not uninstall or clear app data.

This ZIP is build source, not a compiled APK. CI must verify original certificate, package and numeric version. Device/live sync testing remains required.
