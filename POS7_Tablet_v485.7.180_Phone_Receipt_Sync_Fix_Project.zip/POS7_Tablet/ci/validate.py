from html.parser import HTMLParser
from pathlib import Path
import subprocess
import tempfile

class Scripts(HTMLParser):
    def __init__(self):
        super().__init__()
        self.inside = False
        self.external = False
        self.parts = []
        self.scripts = []

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'script':
            self.inside = True
            self.external = 'src' in dict(attrs)
            self.parts = []

    def handle_data(self, data):
        if self.inside:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == 'script' and self.inside:
            if not self.external:
                self.scripts.append(''.join(self.parts))
            self.inside = False

path = Path(
    ''
    'app/src/main/assets/index.html'
)

parser = Scripts()
parser.feed(path.read_text())

checked = 0

for script in parser.scripts:
    if not script.strip():
        continue

    with tempfile.NamedTemporaryFile(
        mode='w',
        suffix='.js'
    ) as f:
        f.write(script)
        f.flush()

        result = subprocess.run(
            ['node', '--check', f.name],
            capture_output=True,
            text=True
        )

        if result.returncode:
            raise SystemExit(
                'JavaScript syntax error:\n'
                + result.stderr
            )

    checked += 1

print(f'Validated {checked} JavaScript blocks')
