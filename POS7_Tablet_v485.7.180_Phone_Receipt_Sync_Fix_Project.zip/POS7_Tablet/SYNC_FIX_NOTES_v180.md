# POS7 v485.7.180 — Emergency phone receipt sync patch

## Scope
Based on original 485.7.178 tablet project. Same package `com.sokkarzeyedeh.pos7` and same enforced signing certificate.
No credentials or database data included.

- Fetch pending phone commands **before** bulk tablet snapshot push.
- Persist financial event with `cloudEventId` + `pos7OwnerApplied` marker in the same localStorage write.
- If a legacy receipt already has the phone event ID but lacks a complete marker, stop, flag for manual review. Do not duplicate.
- After local commit, publish receipt + party balance + applicable cash/ledger details before `processed` ACK.
- Never auto-reject a phone command on a local accounting error; keep `pending` for review.
- Break bulk cloud updates into small partial RPC batches (40 records / ~55k characters maximum), three batches per sync pass.
- Reread server revision and snapshot after timeout / retry; continue unsent batches automatically.
- Avoid generatedAt-driven meta churn and misleading full-sync success status.
- Disable reset/rebind buttons in emergency release to protect pending receipts.

## Safety prerequisites
1. Save a native Android backup from the original tablet. This is an emergency release and is NOT verified against the live Supabase database.
2. Verify the tablet is the original publisher. Do not reinstall or clear application data.
3. The 3 pending receipts totaling $446 MUST be verified against existing ledger to avoid double booking.
4. Build with existing four GitHub signing secrets; never use a different keystore.
5. Use installed_version_code workflow input at least as high as the installed APK's versionCode.
6. Check phone events are fully imported and statement/cash ledger matches before declaring production ready.

## Important
This ZIP is source code, not a signed APK. GitHub Actions builds the APK using your existing POS7 keystore. HTML in this ZIP has write access and MUST NOT be opened on Chrome with production credentials.
