# POS7 Owner Phone v485.7.132-blue — private owner application

Derived from the **v485.7.130 Android phone project** with its existing Java native notification service, FCM integration, application ID, Android permissions and signing rules unchanged; the **v485.7.132 HTML interface** replaces the WebView asset.

- Homepage displays phone version v485.7.132 and gear icon (removes POS7 lettering from the home header).
- Compact profit, cash and wallet cards; quick actions remain accessible.
- Dedicated settings page for four color themes (blue, teal, red-gold, orange-charcoal); local display name, normal/large fonts, reset.
- Theme and display name only affect on-device UI and do **not** rename ERP accounting records or change Supabase.
- Existing device-specific Firebase configuration must be supplied by repository secret. No `google-services.json`, keystore, password or shop records are packaged.
- Original package: `com.sokkarzeyedeh.pos7owner`. Requires original signing certificate to update the installed app without clearing data.

**Build:** Upload `POS7_Phone_v485.7.132_Project.zip` to repository root and copy the supplied `main.yml` to `.github/workflows/main.yml`, then run GitHub Actions. Set `installed_version_code` to the currently installed APK numeric versionCode if it is higher than the default.

**Testing:** JavaScript parsing/syntax and static source checks can be run here. A full signed APK requires the user's GitHub secrets. Android device FCM notifications and cloud synchronization should be verified after installing a signed upgrade. Do not uninstall or reset data.
