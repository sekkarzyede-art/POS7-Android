# POS7 Owner Phone v485.7.133 (Responsive Layout)

Based on v485.7.132. Includes responsive home dashboard for narrow/wide Android screens and three local layout modes: auto, compact and comfortable. Card height adapts to content; settings include existing four color themes and store display name. No accounting, sync, FCM/native notification or database changes.

APK versionName: 485.7.133-blue; applicationId: com.sokkarzeyedeh.pos7owner.

The original signer is required for updates in place. Never uninstall the previous app.
