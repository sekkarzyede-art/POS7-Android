# POS7 Owner Phone v485.7.133-blue — private application

This is an upgrade of the v485.7.132 owner-phone Android project. The Android WebView asset is replaced with the responsive v485.7.133 HTML. Native Android/Firebase/FCM/notification service, package name, permissions and private Supabase logic remain unchanged.

- Home view reflows on Galaxy A17 and Tab 9 display sizes.
- Settings include auto / compact / comfortable density, stored locally.
- Display name and visual themes remain device-local.
- Original application ID: com.sokkarzeyedeh.pos7owner
- Release versionName: 485.7.133-blue
- Release versionCode: supplied securely via POS7_VERSION_CODE, must exceed the installed APK.
- No keystore, passwords, google-services.json or user business data included.

**Building**: upload POS7_Phone_v485.7.133_Project.zip to GitHub repository root; copy provided main.yml to .github/workflows/main.yml and run GitHub Actions with original signing and Firebase secrets. The build verifies the known original signing certificate fingerprint and final APK signature. Do not uninstall the installed app or reset app data.

**Status**: HTML JS syntax is validated here; native APK signing and on-device verification require GitHub Actions and the private signing/Firebase secrets.
