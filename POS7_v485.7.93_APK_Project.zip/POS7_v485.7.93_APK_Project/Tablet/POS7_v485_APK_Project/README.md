# POS7 Tablet APK Project v485.7.93

- Application ID: `com.sokkarzeyedeh.pos7` (unchanged for in-place updates).
- Version code: `4850793`; version name: `485.7.93`.
- Adds an explicit individual sale price in USD to each product row in the sales cart, while retaining stock, LBP selling price, USD cost, quantity controls, and line total.
- Preserves the existing POS7 tablet signing certificate check. The owner phone app and its data are not changed.

Build with the same POS7 tablet release keystore used for the installed tablet APK. Configure GitHub Actions secrets `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`. The workflow verifies certificate SHA-256 `843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495` before and after build; a mismatch fails without uploading an APK.
