package com.sokkarzeyedeh.pos7;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Build;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.util.ArrayList;

public final class MainActivity extends Activity {
    private WebView webView;
    private final ArrayList<WebView> printWebViews = new ArrayList<>();
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_REQUEST = 4510;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        webView.addJavascriptInterface(new AndroidPrintBridge(this), "Pos7Android");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private final class AndroidPrintBridge {
        private final Context context;
        AndroidPrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printHtml(String html, String jobName) {
            if (html == null || html.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(context, "محتوى الطباعة فارغ", Toast.LENGTH_SHORT).show());
                return;
            }
            runOnUiThread(() -> openSystemPrint(html, jobName));
        }
    }

    private void openSystemPrint(String html, String jobName) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
        WebView printView = new WebView(this);
        printWebViews.add(printView);
        printView.getSettings().setJavaScriptEnabled(true);
        printView.setWebViewClient(new WebViewClient() {
            private boolean started;
            @Override public void onPageFinished(WebView view, String url) {
                if (started) return;
                started = true;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager == null) {
                    Toast.makeText(MainActivity.this, "خدمة الطباعة غير متاحة على هذا الجهاز", Toast.LENGTH_LONG).show();
                    return;
                }
                String title = (jobName == null || jobName.trim().isEmpty()) ? "POS7" : jobName.trim();
                PrintAttributes attributes = new PrintAttributes.Builder()
                    .setMediaSize(new PrintAttributes.MediaSize("POS7_80MM", "80 mm thermal", 3150, 11000))
                    .setResolution(new PrintAttributes.Resolution("POS7_203DPI", "203 dpi", 203, 203))
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setColorMode(PrintAttributes.COLOR_MODE_MONOCHROME)
                    .build();
                manager.print(title, view.createPrintDocumentAdapter(title), attributes);
            }
        });
        printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (fileCallback != null) { fileCallback.onReceiveValue(null); fileCallback = null; }
        for (WebView printView : printWebViews) { printView.stopLoading(); printView.destroy(); }
        printWebViews.clear();
        if (webView != null) { webView.stopLoading(); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
