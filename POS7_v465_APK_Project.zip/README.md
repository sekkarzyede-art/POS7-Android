# POS7 v465 — APK مع دليل ربط الطابعة

يضم هذا المشروع نسخة POS7 التجريبية v465 داخل تطبيق Android WebView. أضيف دليل اقتران الطابعة وتفعيل خدمة الطباعة، مع زر لإرسال صفحة اختبار إلى نافذة طباعة Android. يجب إقران الطابعة وتفعيل خدمة الطباعة المناسبة من إعدادات Android أولاً. هذا الإصدار يستخدم نافذة الطباعة في Android ولا ينفذ اتصال Bluetooth مباشرًا بعنوان MAC.

## بناء APK محليًا

يتطلب JDK 17 وAndroid SDK 35 وGradle 8.9. من مجلد المشروع نفّذ:

```bash
gradle --no-daemon assembleDebug
```

الناتج:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## البناء عبر GitHub Actions

يمكن وضع ملفات المشروع في جذر المستودع، أو رفع ملف ZIP إلى جذر المستودع. سير العمل `.github/workflows/main.yml` يتعرف على الحالتين ويبني APK عند الدفع إلى `main` أو عند تشغيله يدويًا. بعد نجاح التشغيل نزّل artifact باسم `POS7-v465-apk`.

الملف الناتج APK تجريبي debug غير مخصص للنشر على Google Play.
