-- POS7 Owner v485.7.57. Run once after the existing POS7 setup.
-- Adds isolated owner-only reporting tables. Does not alter store accounting data.
begin;
create table if not exists public.pos7_owner_snapshot (
 store_id text primary key check(store_id='pos7'),
 sections jsonb not null default '{}'::jsonb,
 revision bigint not null default 0,
 publisher_device text not null,
 updated_at timestamptz not null default now()
);
create table if not exists public.pos7_owner_commands (
 event_id uuid primary key,
 store_id text not null default 'pos7' check(store_id='pos7'),
 event_type text not null check(event_type in ('expense','customer_payment','supplier_payment','owner_wallet')),
 payload jsonb not null check(jsonb_typeof(payload)='object'),
 device_id text not null,
 created_by uuid not null default auth.uid() references auth.users(id),
 created_at timestamptz not null default now(),
 status text not null default 'pending' check(status in ('pending','processed','rejected')),
 result jsonb not null default '{}'::jsonb,
 processed_at timestamptz
);
create index if not exists pos7_owner_commands_pending on public.pos7_owner_commands(store_id,status,created_at);
alter table public.pos7_owner_snapshot enable row level security;
alter table public.pos7_owner_commands enable row level security;
drop policy if exists owner_snapshot_read on public.pos7_owner_snapshot;
create policy owner_snapshot_read on public.pos7_owner_snapshot for select to authenticated using(public.pos7_is_member(store_id,array['owner']));
drop policy if exists owner_commands_read on public.pos7_owner_commands;
create policy owner_commands_read on public.pos7_owner_commands for select to authenticated using(public.pos7_is_member(store_id,array['owner']));
drop policy if exists owner_commands_insert on public.pos7_owner_commands;
create policy owner_commands_insert on public.pos7_owner_commands for insert to authenticated with check(public.pos7_is_member(store_id,array['owner']) and created_by=auth.uid() and status='pending' and result='{}'::jsonb and processed_at is null);
revoke all on public.pos7_owner_snapshot,public.pos7_owner_commands from anon,authenticated;
grant select on public.pos7_owner_snapshot,public.pos7_owner_commands to authenticated;
grant insert(event_id,store_id,event_type,payload,device_id) on public.pos7_owner_commands to authenticated;
create or replace function public.pos7_owner_publish(p_patch jsonb,p_expected bigint,p_device text)
returns bigint language plpgsql security definer set search_path=public,pg_temp as $$
declare cur public.pos7_owner_snapshot%rowtype; k text; v jsonb; doc jsonb; rid text;
begin
 if not public.pos7_is_member('pos7',array['owner']) then raise exception 'Owner access required'; end if;
 if p_device is null or length(p_device)<8 then raise exception 'Device required'; end if;
 if jsonb_typeof(p_patch) is distinct from 'object' then raise exception 'Invalid patch'; end if;
 insert into public.pos7_owner_snapshot(store_id,publisher_device) values('pos7',p_device) on conflict do nothing;
 select * into cur from public.pos7_owner_snapshot where store_id='pos7' for update;
 if cur.publisher_device<>p_device then raise exception 'Another tablet is the publisher'; end if;
 if cur.revision<>p_expected then raise exception 'Revision conflict: refresh and retry'; end if;
 for k,v in select * from jsonb_each(p_patch) loop
  if k<>all(array['meta','products','sales','purchases','returns','customers','suppliers','receipts','payments','expenses','cash','cashLedger','wallet','walletTx']) then raise exception 'Unknown section'; end if;
  if jsonb_typeof(v->'upsert') is distinct from 'object' or jsonb_typeof(v->'remove') is distinct from 'array' then raise exception 'Invalid section'; end if;
  doc=coalesce(cur.sections->k,'{}'::jsonb)||(v->'upsert');
  for rid in select jsonb_array_elements_text(v->'remove') loop doc=doc-rid; end loop;
  cur.sections=jsonb_set(cur.sections,array[k],doc,true);
 end loop;
 update public.pos7_owner_snapshot set sections=cur.sections,revision=cur.revision+1,updated_at=now() where store_id='pos7';
 return cur.revision+1;
end $$;
create or replace function public.pos7_owner_ack(p_id uuid,p_status text,p_result jsonb,p_device text)
returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
 if not public.pos7_is_member('pos7',array['owner']) or not exists(select 1 from public.pos7_owner_snapshot where store_id='pos7' and publisher_device=p_device) then raise exception 'Publisher access required'; end if;
 if p_status not in ('processed','rejected') then raise exception 'Invalid status'; end if;
 update public.pos7_owner_commands set status=p_status,result=p_result,processed_at=now() where event_id=p_id and store_id='pos7' and status='pending';
end $$;
revoke all on function public.pos7_owner_publish(jsonb,bigint,text),public.pos7_owner_ack(uuid,text,jsonb,text) from public;
grant execute on function public.pos7_owner_publish(jsonb,bigint,text),public.pos7_owner_ack(uuid,text,jsonb,text) to authenticated;
commit;
-- Sign in on the new phone with the existing OWNER account.
-- The old phone_entry account cannot read owner financial reports.
