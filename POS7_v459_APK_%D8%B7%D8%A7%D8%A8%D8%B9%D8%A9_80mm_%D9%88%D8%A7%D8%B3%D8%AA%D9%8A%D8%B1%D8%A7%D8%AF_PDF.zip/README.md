# POS7 v456 — APK تجريبي مع الطباعة عبر Android

يتضمن هذا المشروع نسخة POS7 HTML داخل تطبيق Android WebView. تدعم هذه النسخة فتح إيصال الطباعة عبر نافذة طباعة Android، مع بقاء الطباعة في Chrome عبر نافذة المتصفح. في أول تشغيل لنسخة v451 تُمسح مفاتيح POS7 المحلية مرة واحدة، ثم يبدأ المخزون والفواتير والسندات فارغًا. رقم فاتورة البيع التالي يبدأ من SAL-000001 بحسب تسلسل البرنامج.

## بناء APK

افتح المجلد في Android Studio مع Android SDK 35 وJDK 17، ثم نفذ:

```bash
gradle assembleDebug
```

يظهر الملف الناتج في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

أو ارفع المجلد إلى مستودع GitHub وشغّل الإجراء اليدوي **Build POS7 v456 APK with Android printing**، ثم نزّل artifact باسم `POS7-v456-print-fix-debug-apk`.

الحزمة الحالية غير موقعة للنشر على Google Play؛ إنها APK debug للتثبيت التجريبي.


## v458 PDF import fix

Added Android INTERNET permission required by the PDF.js CDN used for customer and supplier PDF imports. This lets the WebView load the PDF reader when the device has internet access.


## v459 80 mm printer selection fix

In the Android APK, the printer selection button opens the native Android 80 mm print dialog. This avoids Web Bluetooth, which is unavailable in the local WebView context. Customer/supplier PDF import keeps the v458 Internet permission.
