# POS7 Tablet APK Project v485.7.84

- Application ID: `com.sokkarzeyedeh.pos7`
- Version code: `4850784`
- Version name: `485.7.84`
- The phone app project and cloud-link credentials are not changed.
- This tablet release uses the current HTML and standardizes report date defaults and display as DD/MM/YYYY.

## Signing and update compatibility

Build with the same release keystore that signed the installed POS7 tablet APK. Configure these GitHub repository secrets: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, `POS7_KEY_PASSWORD`. The workflow checks the expected installed certificate fingerprint before and after building. A different key fails the workflow and no APK artifact is uploaded.

## Build

Commit this ZIP and the supplied `.github/workflows/main.yml` to the repository's `main` branch, or run the workflow manually. It produces the signed tablet APK as a workflow artifact. Install it as an update; do not uninstall the existing app.
