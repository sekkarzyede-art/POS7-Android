# POS7 Tablet v485.7.191 — Purchase calculator action visibility

- Source version: v485.7.191, package `com.sokkarzeyedeh.pos7`.
- Center purchase calculator buttons: **حفظ فاتورة الشراء** / **عودة إلى الأصناف**.
- Return action preserves unsaved purchase basket. Invoice save logic is unchanged.
- Inherits supplier quick list v189, midnight sale date fix v188, sync/backup behavior from v187 and earlier.
- Never clear Android application storage or uninstall the existing application to upgrade.
- GitHub Actions `.github/workflows/main.yml` at repository root builds and verifies signed APK using the original certificate.
- Required existing GitHub secrets: POS7_KEYSTORE_BASE64, POS7_KEYSTORE_PASSWORD, POS7_KEY_ALIAS, POS7_KEY_PASSWORD.
- Original signing certificate SHA256: 843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495.
- An actual APK signed with the original private key must be built in GitHub. Project ZIP is source only.
- When using manually-triggered workflow, enter the ACTUAL installed APK versionCode if greater than the default.
