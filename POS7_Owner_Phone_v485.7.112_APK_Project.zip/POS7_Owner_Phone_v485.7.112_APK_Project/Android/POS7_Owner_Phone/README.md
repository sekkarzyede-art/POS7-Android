# POS7 Owner Phone APK Project v485.7.112

- Version: `485.7.112` (version code `48507112`).
- This APK wraps the owner-phone HTML build in `app/src/main/assets/index.html`.
- Android application id: `com.sokkarzeyedeh.pos7owner`, separate from the tablet POS app so the phone build cannot replace it.
- Store records and sync behavior are provided by the bundled HTML; this build does not clear application data.

## Build with GitHub Actions

Upload this project zip to the repository root and copy the supplied `main.yml` into `.github/workflows/main.yml`. The workflow uses the existing POS7 signing secrets: `POS7_KEYSTORE_BASE64`, `POS7_KEYSTORE_PASSWORD`, `POS7_KEY_ALIAS`, and `POS7_KEY_PASSWORD`.

The signed APK is published as the workflow artifact `POS7-Owner-Phone-v485.7.112-apk`.
