# POS7 v456 — APK تجريبي مع الطباعة عبر Android

يتضمن هذا المشروع نسخة POS7 HTML داخل تطبيق Android WebView. تدعم هذه النسخة فتح إيصال الطباعة عبر نافذة طباعة Android، مع بقاء الطباعة في Chrome عبر نافذة المتصفح. في أول تشغيل لنسخة v456 تُمسح مفاتيح POS7 المحلية مرة واحدة، ثم يبدأ المخزون والفواتير والسندات فارغًا. رقم فاتورة البيع التالي يبدأ من SAL-000001 بحسب تسلسل البرنامج.

## بناء APK

افتح المجلد في Android Studio مع Android SDK 35 وJDK 17، ثم نفذ:

```bash
gradle assembleDebug
```

يظهر الملف الناتج في:

```text
app/build/outputs/apk/debug/app-debug.apk
```

أو ارفع المجلد إلى مستودع GitHub وشغّل الإجراء اليدوي **Build POS7 v456 APK with Android printing**، ثم نزّل artifact باسم `POS7-v456-print-fix-debug-apk`.

الحزمة الحالية غير موقعة للنشر على Google Play؛ إنها APK debug للتثبيت التجريبي.
