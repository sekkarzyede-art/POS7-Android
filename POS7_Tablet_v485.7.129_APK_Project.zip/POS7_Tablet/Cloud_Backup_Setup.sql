-- Run once in the SAME Supabase project used by POS7 owner sync.
-- No changes to invoices, balances, owner snapshots or command queues.
begin;
create table if not exists public.pos7_full_backups (
 id uuid primary key default gen_random_uuid(),
 store_id text not null,
 owner_id uuid not null references auth.users(id),
 created_at timestamptz not null default now(),
 file_name text not null check (length(file_name) between 1 and 180),
 app_version text not null,
 payload text not null,
 size_bytes integer not null check (size_bytes > 0 and size_bytes <= 52428800),
 constraint pos7_full_backup_size_matches check (octet_length(payload)=size_bytes),
 constraint pos7_full_backup_valid check (
   coalesce(payload::jsonb->>'app'='POS7',false)
   and coalesce(jsonb_typeof(payload::jsonb->'data'->'products')='array',false)
   and coalesce(jsonb_typeof(payload::jsonb->'data'->'sales')='array',false)
   and coalesce(jsonb_typeof(payload::jsonb->'data'->'purchases')='array',false)
 )
);
create index if not exists pos7_full_backups_owner_date on public.pos7_full_backups(owner_id,store_id,created_at desc);
alter table public.pos7_full_backups enable row level security;
revoke all on public.pos7_full_backups from anon, authenticated;
grant select, insert on public.pos7_full_backups to authenticated;
drop policy if exists pos7_full_backup_read on public.pos7_full_backups;
create policy pos7_full_backup_read on public.pos7_full_backups for select to authenticated
using (owner_id=(select auth.uid()) and exists (
 select 1 from public.pos7_members m where m.store_id=pos7_full_backups.store_id and m.user_id=(select auth.uid()) and m.role='owner'
));
drop policy if exists pos7_full_backup_insert on public.pos7_full_backups;
create policy pos7_full_backup_insert on public.pos7_full_backups for insert to authenticated
with check (owner_id=(select auth.uid()) and exists (
 select 1 from public.pos7_members m where m.store_id=pos7_full_backups.store_id and m.user_id=(select auth.uid()) and m.role='owner'
));
notify pgrst, 'reload schema';
commit;
