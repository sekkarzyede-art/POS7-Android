# POS7 Tablet 485.7.129
Base UI: user-approved tablet 485.7.94. Native Android wrapper: tablet 485.7.104.
Adds independent cloud backups of the existing full business state and native JSON-file sharing.
Does not alter accounting, Bluetooth printing, data keys, owner snapshot sync or phone notifications.
Package: com.sokkarzeyedeh.pos7. Keep original release signing secrets.
Run Cloud_Backup_Setup.sql once in the existing Supabase project; sign in as the same owner in tablet sync.
Cloud backups are private per owner and store, append-only; existing backups are not overwritten. Manually manage retention in Supabase as needed.
Cloud download only saves a JSON file. Restore through the existing restore button, with its existing confirmation/password.
Backup includes persisted business state, not unsaved invoices, Android settings or cloud session credentials.
WhatsApp chooser opening is not proof of delivery. User chooses recipient and sends.
No live Supabase migration or actual Android APK compilation/device test performed here.

Fixes supplier statement period refresh: restricts the legacy customer click interceptor to buttons contained in the active customer page.
