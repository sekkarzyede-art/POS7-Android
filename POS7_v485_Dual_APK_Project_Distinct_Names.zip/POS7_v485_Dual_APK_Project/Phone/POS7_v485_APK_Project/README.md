# POS7 485.7.66 — Phone APK source

This project contains the phone interface in `app/src/main/assets/index.html`. The package id remains `com.sokkarzeyedeh.pos7`; Android versionCode is 487 so this APK can update earlier builds. Build and sign it with the supplied root `main.yml` and the existing signing secrets.
