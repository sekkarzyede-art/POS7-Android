# POS7 485.7.65 — Tablet APK source

This project contains the tablet interface in `app/src/main/assets/index.html`. The package id remains `com.sokkarzeyedeh.pos7`; Android versionCode is 487 so this APK can update earlier builds. Build and sign it with the supplied root `main.yml` and the existing signing secrets.
