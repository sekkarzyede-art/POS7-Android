# Fixed POS7 tablet rules — version485.7.130

- Baseline: user's successful tablet485.7.104, both HTML and native Android wrapper. Do not substitute the older94 interface.
- Package/namespace: com.sokkarzeyedeh.pos7. Retain file:///android_asset/index.html and existing WebView storage keys/schema. No clearing data on startup/update. Phone package is distinct; never replace it with tablet.
- Original signing SHA256: 843ed618b18ec7a0cbb50f38984374540da016c41a8df8042bb8db19964d4495.
- Original signing SHA1: dd506b27b180ef7a12014e4ee4f6bc4e2d1e8a08. Never distribute a replacement or debug signing key. Original four POS7 GitHub secrets remain required.
- Upgrade in place: same package+certificate and greater versionCode than installed. VersionName alone does not prove upgrade compatibility. Refuse unsigned release. Keep manifest/UI/release filename version aligned.
- Java17, Gradle8.9, AGP8.7.3, compile/target35, min23. New dependencies pinned: play-services-auth21.4.0; androidx.core1.13.1.
- Existing tablet→phone Supabase synchronization, Firebase phone notifications, Bluetooth printing, accounting, receipt layout, permissions and restore confirmation/password are preserved from104. No SQL required for Google Drive backups.
- USD remains accounting base; do not rewrite currency conversions or ledger balances for this change.
- Supplier report defaults may be today, but the report must honor manually selected inclusive from/to dates and opening balance. Customer click interception only applies to buttons inside active customerDetails.
- Backup snapshot uses existing makeBackupObject and validBackup. Drive and WhatsApp export complete existing business state, not only owner-phone snapshots. No automatic restore on download.
- Drive requests occur only from an explicit backup-page action, never at startup. Remember selected Google account; do not require a different Gmail from sync. OAuth authorization is separate from Supabase login.
- Drive OAuth token stays native. Scope drive.file, app-tagged files, new JSON per backup; no overwrite/delete of old backups. Account disconnect revokes access without deleting backup files.
- File sharing: FileProvider limited to cache/shared_backups, read-only temporary URI grant; user selects WhatsApp recipient and sends. Never claim successful delivery from chooser opening.
- Test HTML first for UI; native Drive and sharing require device APK validation. Be explicit about untested live integrations and build results.
- Future updates: keep these rules with project and update them only for explicit approved changes. Preserve105+ changes only when actually present in selected baseline; do not claim features from unrelated builds.

## Build 485.7.151 — 2026-10-28
- Approved UI: v485.7.151 periods + floating calculator, based on v150 report pagination and v149/v139 UI branch.
- Native wrapper remains startup-fixed v130; no changes to Java, storage origin, permissions, cloud credentials or native Drive/printing.
- All UI version writers and header caption now say 485.7.151. Android versionName is 485.7.151.
- Minimum versionCode 48507510; workflow max(48507510, installed_version_code+1, 48507509+run_number). User can supply the actual installed code when higher.
- Signature must match the original SHA256 above; no fallback signing.
- Source validation is separate from CI signature validation and device installation tests.

## Build 485.7.163
- Uses cumulative HTML163, including changes152–163; no multi-barcode or product merging.
- Caption/versionName163; minimum code48507630, max(installed+1,48507629+run_number,48507630).
- Java changed only for independent backup bridge, readback verification and retention20 in selected persistent SAF folder.
- Retention applies only to valid POS7_Independent_<timestamp>_<suffix>.json files. Protect new verified file even after clock rollback. Do not delete unrelated or cloud files.
- Preserve original four signing secrets and fail if certificate differs. No debug or replacement signing key.
- Source checks are not an Android compilation or device test.

## 485.7.165
Preserve live WebView on size changes; never reload in configuration/resume callbacks. Preserve auth and explicit logout. UI-only resume changes; no accounting or cloud mutations. Existing session restoration remains limited; do not claim indefinite draft recovery. Use original signing only.
